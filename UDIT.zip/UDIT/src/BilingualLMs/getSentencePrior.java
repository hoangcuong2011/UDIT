package BilingualLMs;


import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import kylm.model.ngram.NgramLM;
import kylm.model.ngram.reader.ArpaNgramReader;
import kylm.reader.TextStreamSentenceReader;
import kylm.util.KylmConfigUtils;
import kylm.util.KylmMathUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hoangcuong2011
 */
public class getSentencePrior {

    public static void main(String args[]) throws IOException, Exception {
        getSentencePrior program = new getSentencePrior();
        if (args.length == 6) {
            String filename_dev = args[0];
            String filename_test = args[1];
            int domain = Integer.parseInt(args[2]);
            int times = Integer.parseInt(args[3]);
            int number_of_domains = Integer.parseInt(args[4]);
            String file = args[5];
            program.getSentencePrior(filename_dev, filename_test, domain, times, number_of_domains, file);
        } else {
            System.out.println("trianing ...");
            String filename_dev = args[0];
            String filename_test = "";
            int domain = Integer.parseInt(args[1]);
            int times = Integer.parseInt(args[2]);
            int number_of_domains = Integer.parseInt(args[3]);
            String file = args[4];
            program.getSentencePrior(filename_dev, filename_test, domain, times, number_of_domains, file);
        }
    }

    public ArrayList<Double> getSentencePrior(String filename_dev, String filename_test, int domain, int iteration, int total_domains,
            String file) throws Exception {
        ArrayList<Double> sentenceProb = new ArrayList<Double>();
        String text = "-arpa " + "abc" + " " + "abc";
        String[] args = text.trim().split(" ");
        final String br = System.getProperty("line.separator");
        KylmConfigUtils config = new KylmConfigUtils(
                "CrossEntropy" + br
                + "A program to find the cross-entropy of one or more language models over a test set" + br
                + "Example: java -cp kylm.jar kylm.main.CrossEntropy -arpa model1.arpa:model2.arpa test.txt");

        // Input format options
        config.addEntry("arpa", KylmConfigUtils.STRING_ARRAY_TYPE, null, false, "models in arpa format (model1.arpa:model2.arpa)");
        config.addEntry("bin", KylmConfigUtils.STRING_ARRAY_TYPE, null, false, "models in binary format (model3.bin:model4.bin)");

        // Debugging options
        config.addEntry("debug", KylmConfigUtils.INT_TYPE, 0, false, "the level of debugging information to print");

        // parse the arguments
        args = config.parseArguments(args);
        int debug = config.getInt("debug");

        // a vector to hold the models
        ArpaNgramReader anr = new ArpaNgramReader();
        String arpa = file+".ournew_" + domain + "_" + "iteration_" + iteration + "totaldomains_" + total_domains;
        NgramLM next = anr.read(arpa);
        if (next.getName() == null) {
            next.setName(arpa);
        }

        if (1 == 1) {
            // get the input stream to load the input
            InputStream is = (args.length == 0 ? System.in : new FileInputStream(filename_dev));
            TextStreamSentenceReader tssl = new TextStreamSentenceReader(is);
// calculate the entropies
            ArrayList<Double> words = new ArrayList<Double>();
            int wordCount = 0, sentenceCount = 0;
            for (String[] sent : tssl) {
                String tmp1 = "";
                String tmp2 = "";
                for (int i = 0; i < sent.length; i++) {
                    tmp1 += sent[i] + " ";
                }
                for (int i = sent.length - 1; i >= 0; i--) {
                    tmp2 += sent[i] + " ";
                }
                tmp1 += "";
                tmp2 += "";
                tmp1 = tmp1.trim();
                tmp2 = tmp2.trim();
                String[] sent1 = tmp1.split(" ");
                String[] sent2 = tmp2.split(" ");
                double temp = Math.pow(10, next.getSentenceProb(sent1));
                if(temp<1E-200)
                    temp = 1E-200;
                sentenceProb.add(sentenceCount, temp);
                if (filename_test.length() > 0) {

                    words.add(sentenceCount, KylmMathUtils.sum(next.getWordEntropies(sent1)));
                }

                sentenceCount++;
            }

            FileWriter fi_w = new FileWriter(file+"."+filename_dev + "_" + domain + "_" + iteration + "_" + total_domains);
            for (int i = 0; i < sentenceProb.size(); i++) {
                fi_w.write(sentenceProb.get(i) + "\n");
            }
            fi_w.close();

            fi_w = new FileWriter(file+".perplexity_" + filename_dev + "_" + domain + "_" + iteration + "_" + total_domains);
            for (int i = 0; i < words.size(); i++) {
                fi_w.write(words.get(i) + "\n");
            }
            fi_w.close();
        }
        if (1 == 1) {
            if (filename_test.trim().length() == 0) {
                return sentenceProb;
            }
            // get the input stream to load the input
            InputStream is = (args.length == 0 ? System.in : new FileInputStream(filename_test));
            TextStreamSentenceReader tssl = new TextStreamSentenceReader(is);
            ArrayList<Double> words = new ArrayList<Double>();

            int wordCount = 0, sentenceCount = 0;
            for (String[] sent : tssl) {
                String tmp1 = "";
                String tmp2 = "";
                for (int i = 0; i < sent.length; i++) {
                    tmp1 += sent[i] + " ";
                }
                for (int i = sent.length - 1; i >= 0; i--) {
                    tmp2 += sent[i] + " ";
                }
                tmp1 += "";
                tmp2 += "";
                tmp1 = tmp1.trim();
                tmp2 = tmp2.trim();
                String[] sent1 = tmp1.split(" ");
                String[] sent2 = tmp2.split(" ");
                double temp = Math.pow(10, next.getSentenceProb(sent1));
                if(temp<1E-200)
                    temp = 1E-200;
                sentenceProb.add(sentenceCount, temp);
                words.add(sentenceCount, KylmMathUtils.sum(next.getWordEntropies(sent1)));
                sentenceCount++;
            }
            FileWriter fi_w = new FileWriter(file+"."+filename_test + "_" + domain + "_" + iteration + "_" + total_domains);
            for (int i = 0; i < sentenceProb.size(); i++) {
                fi_w.write(sentenceProb.get(i) + "\n");
            }
            fi_w.close();

            fi_w = new FileWriter(file+".perplexity_" + filename_test + "_" + domain + "_" + iteration + "_" + total_domains);
            for (int i = 0; i < words.size(); i++) {
                fi_w.write(words.get(i) + "\n");
            }
            fi_w.close();
        }

        return sentenceProb;
    }
}
