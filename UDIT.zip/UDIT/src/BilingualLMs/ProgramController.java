package BilingualLMs;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import kylm.model.ngram.NgramLM;
import kylm.model.ngram.reader.ArpaNgramReader;
import kylm.reader.TextStreamSentenceReader;
import kylm.util.KylmConfigUtils;
import kylm.util.KylmMathUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hoangcuong201In
 * 
 * 
 */




class DataProcessor implements Runnable {
    String text;
    public DataProcessor(String text){
        this.text = text;
    }
 
    @Override
    public void run() {
        try {
            //System.out.println("Processing data: " + data);
            
            runCommand("java -Xmx250g -cp ./UDIT.jar BilingualLMs.getSentencePrior " 
                    + text); 
            //System.out.println(text);
            // Data processing goes here
        } catch (IOException ex) {
            ex.printStackTrace();
            Logger.getLogger(DataProcessor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
            Logger.getLogger(DataProcessor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void runCommand(String command) throws IOException, InterruptedException {
        int count = 0;
        Process p = Runtime.getRuntime().exec(command);

        BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));

        BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));

        // read the output from the command
        String s = "";
        while ((s = stdInput.readLine()) != null) {
            System.out.println(s);
        }
        while ((s = stdError.readLine()) != null) {
            System.out.println(s);
        }
        try {
            int exitVal = p.waitFor();
            System.out.println("Done Controller");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        count++;
    }

}

class DataProcessorMain implements Runnable {
    String text;
    public DataProcessorMain(String text){
        this.text = text;
    }
 
    @Override
    public void run() {
        try {
            //System.out.println("Processing data: " + data);
            
            runCommand(text); 
            //System.out.println(text);
            // Data processing goes here
        } catch (IOException ex) {
            ex.printStackTrace();
            Logger.getLogger(DataProcessorMain.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
            Logger.getLogger(DataProcessorMain.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void runCommand(String command) throws IOException, InterruptedException {
        int count = 0;
        Process p = Runtime.getRuntime().exec(command);

        BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));

        BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));

        // read the output from the command
        String s = "";
        while ((s = stdInput.readLine()) != null) {
            System.out.println(s);
        }
        while ((s = stdError.readLine()) != null) {
            System.out.println(s);
        }
        try {
            int exitVal = p.waitFor();
            System.out.println("Done Controller");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        count++;
    }

}
public class ProgramController {

    public void runCommand(String command) throws IOException, InterruptedException {
        int count = 0;
        Process p = Runtime.getRuntime().exec(command);

        BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));

        BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));

        // read the output from the command
        String s = "";
        while ((s = stdInput.readLine()) != null) {
            System.out.println(s);
        }
        while ((s = stdError.readLine()) != null) {
            System.out.println(s);
        }
        try {
            int exitVal = p.waitFor();
            System.out.println("Done Controller");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        count++;
    }

    
    public int loadFileSize(String file) throws IOException {
        int filesize = 0;
        BufferedReader buf = new BufferedReader(new FileReader(file));
        String s = "";
        while ((s = buf.readLine()) != null) {
            if (s.trim().length() > 0) {
                filesize++;
            }
        }
        buf.close();
        return filesize;
    }

    
    public void writedownPerpl(String file, int iteration, int number_of_domains, int threads) throws IOException, Exception {

        
        final ExecutorService executor = Executors.newFixedThreadPool(threads);
        final List<Callable<Object>> tasks = new ArrayList<Callable<Object>>();

        for (int i = 0; i < number_of_domains; i++) {
            String parameter = "./acl_kneserney lm -train -i=./"+file+" -order=3 -interpolate -o="+file+".ournew_"
                    + i + "_iteration_" + (iteration) + "totaldomains_" + number_of_domains
                    + " -w=fractionCounts_" + i + "_iteration_" + (iteration) + "totaldomains_" + number_of_domains;
            System.out.println(parameter);
            tasks.add(Executors.callable(new DataProcessorMain(parameter)));
        }
        executor.invokeAll(tasks);
        executor.shutdown();  // not really necessary if the executor goes out of scope.
        System.out.println("Finished all threads");
    }
    
    
    public double randomGenerating() {
        Random r = new Random();
        double randomValue = 0.001 + (0.01-0.001) * r.nextDouble();
        return randomValue;
    }   

    public void createFile(int number_of_domains, int times, String file, int threads) throws InterruptedException {
        final ExecutorService executor = Executors.newFixedThreadPool(threads);
        final List<Callable<Object>> tasks = new ArrayList<Callable<Object>>();

        for (int d = 0; d < number_of_domains; d++) {
            String parameter = file + " " + 
                    d+" "+times+" "+number_of_domains+" "+file;
            tasks.add(Executors.callable(new DataProcessor(parameter)));

        }

        executor.invokeAll(tasks);
        executor.shutdown();  // not really necessary if the executor goes out of scope.
        System.out.println("Finished all threads");                
    }
    
    public void initializeParameters(int number_of_domains, int times, int corpusSize, int threads) throws IOException, Exception {
        //global variables
        double fractional = (double) 1 / (double) number_of_domains;
        for (int domain = 0; domain < number_of_domains; domain++) {
            FileWriter fi_w = new FileWriter("fractionCounts_"
                    + domain + "_iteration_" + times + "totaldomains_" + number_of_domains);
            for (int count = 0; count < corpusSize; count++) {
                double abc = fractional + randomGenerating();
                fi_w.write(abc + "\n");
            }
            fi_w.close();
        }
        writedownPerpl("en.output", times, number_of_domains, threads);
        writedownPerpl("fr.output", times, number_of_domains, threads);
        createFile(number_of_domains, times, "en.output", threads);
        createFile(number_of_domains, times, "fr.output", threads);
    }
    public static void main(String args[]) throws IOException, InterruptedException, Exception {
        System.out.println("Program controller ...");
        int number_of_domains = Integer.parseInt(args[0]);
        int threads = Integer.parseInt(args[1]);
        

        ProgramController program = new ProgramController();
        program.runCommand("cp -r small_data/train.en corpus.lowercased.en");
        program.runCommand("cp -r small_data/train.fr corpus.lowercased.en");
        program.runCommand("cp -r small_data/train.en en.output");
        program.runCommand("cp -r small_data/train.fr fr.output");
        int corpusSize = program.loadFileSize("small_data/train.en");
        
        int times = 1;

        program.initializeParameters(number_of_domains, times, corpusSize, threads);
        program.runCommand("java -Xmx250g -cp ./UDIT.jar BilingualLMs.TrainLatentModel "
                + number_of_domains + " " + times + " " + "en.output" + " " + "fr.output " + threads);
        program.createFile(number_of_domains, times, "en.output", threads);
        program.createFile(number_of_domains, times, "fr.output", threads);

    }
}

