package BilingualLMs;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Vector;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import kylm.model.LanguageModel;
import kylm.model.ngram.NgramLM;
import kylm.model.ngram.reader.ArpaNgramReader;
import kylm.model.ngram.reader.SerializedNgramReader;
import kylm.model.ngram.smoother.AbsoluteSmoother;
import kylm.model.ngram.smoother.GTSmoother;
import kylm.model.ngram.smoother.KNSmoother;
import kylm.model.ngram.smoother.MKNSmoother;
import kylm.model.ngram.smoother.MLSmoother;
import kylm.model.ngram.smoother.NgramSmoother;
import kylm.model.ngram.smoother.WBSmoother;
import kylm.model.ngram.writer.ArpaNgramWriter;
import kylm.model.ngram.writer.NgramWriter;
import kylm.reader.SentenceReader;
import kylm.reader.TextFileSentenceReader;
import kylm.reader.TextStreamSentenceReader;
import kylm.util.KylmConfigUtils;
import kylm.util.KylmMathUtils;
import kylm.util.KylmTextUtils;
import kylm.util.SymbolSet;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hoangcuong2011
 */
public class TrainLatentModel {

    ArrayList<ArrayList<Float>> PriorSent = null;
    ArrayList<Float> prior = null;
    
    

    public int countMatching(String text, String patternText) {
        Pattern pattern = Pattern.compile(patternText);
        Matcher matcher = pattern.matcher(text);

        int count = 0;
        while (matcher.find()) {
            count++;
        }
        return count;
    }

    public void MStepForPrior(int domains, int num_of_sents, int iteration) throws IOException {
        FileWriter fi_w = new FileWriter("prior_"+iteration+"_"+"domains"+domains);
        ArrayList<Float> domainPriorExpectation = new ArrayList<Float>(domains);
        for (int d = 0; d < domains; d++) {
            domainPriorExpectation.add(0.0f);
        }
        float total = 0.0f;
        for (int i = 0; i < num_of_sents; i++) {
            for (int d = 0; d < domains; d++) {
                domainPriorExpectation.set(d, domainPriorExpectation.get(d)
                        + PriorSent.get(d).get(i));
                total += PriorSent.get(d).get(i);
            }
        }
        prior = new ArrayList<Float>();
        for (int d = 0; d < domains; d++) {
            prior.add(0.0f);
            prior.set(d, domainPriorExpectation.get(d) / total);
            System.out.println(prior.get(d));
            fi_w.write(prior.get(d)+"\n");
        }
        fi_w.close();
    }
     
    

    public void reWrite(String input, String output) throws FileNotFoundException, IOException {
        FileReader fi = new FileReader(input);
        BufferedReader buf = new BufferedReader(fi);
        FileWriter fi_w = new FileWriter(output);
        String s = "";
        while ((s = buf.readLine()) != null) {
            s = s.trim().toLowerCase();
            if(s.length()==0)
                continue;            
            fi_w.write(s + "\n");
        }
        buf.close();
        fi_w.close();
    }

    
    
    
    
    
    
    public void Spliting(String fileEN, String fileFR, int number_of_domains, int num_of_sents,
            int total_iterations, int iteration, int threads) throws Exception {
        System.out.println("Start EM algorithm");
        for (int i = 0; i < total_iterations; i++) {
            EM(iteration, fileEN, fileFR, 5-1, number_of_domains, num_of_sents, number_of_domains, threads);            
        }
        
    }

    public static void main(String args[]) throws IOException, Exception {
        int number_of_domains = Integer.parseInt(args[0]);
        int times = Integer.parseInt(args[1]);
        
        int total_iterations = 1;
        TrainLatentModel program = new TrainLatentModel();
        String fileEN = args[2];
        String fileFR = args[3];
        int threads = Integer.parseInt(args[4]);
        int num_of_sents = program.getLineCountFile(fileEN);
        program.Spliting(fileEN, fileFR, number_of_domains, num_of_sents, total_iterations, times, threads);
        System.out.println("done with " + number_of_domains + " ......");
    }

    public void trainLMwithoutSmoothing(String args[]) throws IOException, Exception {
        //program.perplexitywithlatent_sum("ournew_" + 0, predictTree);
        String text = "-n 5 train.output kneserNeyFromText.arpa.kylm";
        args = text.trim().split(" ");
        final String br = System.getProperty("line.separator");
        KylmConfigUtils config = new KylmConfigUtils(
                "CountNgrams" + br
                + "A program to calculate an n-gram language model given a training corpus" + br
                + "Example: java -cp kylm.jar kylm.main.CountNgrams training.txt model.arpa");

        // Ngram Model Options
        config.addGroup("N-gram model options");
        config.addEntry("n", KylmConfigUtils.INT_TYPE, 3, false, "the length of the n-gram context");
        config.addEntry("trim", KylmConfigUtils.INT_ARRAY_TYPE, null, false,
                "the trimming for each level of the n-gram (example: 0:1:1)");
        config.addEntry("name", KylmConfigUtils.STRING_TYPE, null, false, "the name of the model");
        config.addEntry("smoothuni", KylmConfigUtils.BOOLEAN_TYPE, false, false, "whether or not to smooth unigrams");

        // vocabulary options
        config.addGroup("Symbol/Vocabulary options");
        config.addEntry("vocab", KylmConfigUtils.STRING_TYPE, null, false, "the vocabulary file to use");
        config.addEntry("startsym", KylmConfigUtils.STRING_TYPE, "<s>", false, "the symbol to use for sentence starts");
        config.addEntry("termsym", KylmConfigUtils.STRING_TYPE, "</s>", false, "the terminal symbol for sentences");
        config.addEntry("vocabout", KylmConfigUtils.STRING_TYPE, null, false, "the vocabulary file to write out to");
        config.addEntry("ukcutoff", KylmConfigUtils.INT_TYPE, 0, false, "the cut-off for unknown words");
        config.addEntry("uksym", KylmConfigUtils.STRING_TYPE, "<unk>", false, "the symbol to use for unknown words");
        config.addEntry("ukexpand", KylmConfigUtils.BOOLEAN_TYPE, false, false, "expand unknown symbols in the vocabulary");
        config.addEntry("ukmodel", KylmConfigUtils.STRING_ARRAY_TYPE, null, false, "model unknown words. Arguments are processed first to last, so the most general model should be specified last. Format: \"symbol:vocabsize[:regex(.*)][:order(2)][:smoothing(wb)]\"");

        // class options
        config.addGroup("Class options");
        config.addEntry("classes", KylmConfigUtils.STRING_TYPE, null, false, "a file containing word class definitions");

        // Smoothing options
        config.addGroup("Smoothing options [default: kn]");
        config.addEntry("ml", KylmConfigUtils.BOOLEAN_TYPE, true, false, "maximum likelihood smoothing");
        config.addEntry("gt", KylmConfigUtils.BOOLEAN_TYPE, false, false, "Good-Turing smoothing (Katz Backoff)");
        config.addEntry("wb", KylmConfigUtils.BOOLEAN_TYPE, false, false, "Witten-Bell smoothing");
        config.addEntry("abs", KylmConfigUtils.BOOLEAN_TYPE, false, false, "absolute smoothing");
        config.addEntry("kn", KylmConfigUtils.BOOLEAN_TYPE, false, false, "Kneser-Ney smoothing (default)");
        config.addEntry("mkn", KylmConfigUtils.BOOLEAN_TYPE, false, false, "Modified Kneser-Ney smoothing (of Chen & Goodman)");

        // Output format options
        config.addGroup("Output options [default: arpa]");
        config.addEntry("bin", KylmConfigUtils.BOOLEAN_TYPE, false, false, "output in binary format");
        config.addEntry("wfst", KylmConfigUtils.BOOLEAN_TYPE, false, false, "output in weighted finite state transducer format (WFST)");
        config.addEntry("arpa", KylmConfigUtils.BOOLEAN_TYPE, true, false, "output in ARPA format");
        config.addEntry("neginf", KylmConfigUtils.DOUBLE_TYPE, null, false, "the number to print for non-existent backoffs (default: null, example: -99)");

        // Debugging options
        config.addGroup("Miscellaneous options");
        config.addEntry("debug", KylmConfigUtils.INT_TYPE, 0, false, "the level of debugging information to print"); // the level of debugging output to write

        // parse the arguments
        args = config.parseArguments(args);
        int debug = config.getInt("debug");

        // check the validity of the arguments
        int n = config.getInt("n");
        if (args.length > 2
                || n == -1) {
            config.exitOnUsage();
        }

        // choose the smoother
        NgramSmoother smoother = null;
        if (config.getBoolean("ml")) {
            smoother = new MLSmoother();
        } else if (config.getBoolean("gt")) {
            smoother = new GTSmoother();
        } else if (config.getBoolean("wb")) {
            smoother = new WBSmoother();
        } else if (config.getBoolean("abs")) {
            smoother = new AbsoluteSmoother();
        } else if (config.getBoolean("mkn")) {
            smoother = new MKNSmoother();
        } else if (config.getBoolean("kn")) {
            smoother = new KNSmoother();
        }
        if (smoother == null) {
            System.err.println("A type of smoothing must be chosen (ml|gt|wb|abs|kn|mkn)");
            config.exitOnUsage(1);
        }
        smoother.setDebugLevel(debug);
        smoother.setSmoothUnigrams(config.getBoolean("smoothuni"));

        // pick the writer type
        NgramWriter writer = null;
        writer = new ArpaNgramWriter();
        Object negInf = config.getValue("neginf");
        if (negInf != null) {
            ((ArpaNgramWriter) writer).setNegativeInfinity((Double) negInf);
        }

        // create the input sentence loader
        SentenceReader loader
                = (args.length > 0
                        ? new TextFileSentenceReader(args[0])
                        : new TextStreamSentenceReader(System.in));

        // create the n-gram model
        NgramLM lm = new NgramLM(n, smoother);
        lm.getSmoother().setCutoffs(config.getIntArray("trim"));
        lm.setDebug(debug);
        lm.setName(config.getString("name"));
        lm.setUnknownSymbol(config.getString("uksym"));
        lm.setVocabFrequency(config.getInt("ukcutoff"));
        lm.setStartSymbol(config.getString("startsym"));
        lm.setTerminalSymbol(config.getString("termsym"));

        // load the unknown models
        String[] ukStrings = config.getStringArray("ukmodel");
        if (ukStrings != null) {
            NgramLM[] ukModels = new NgramLM[ukStrings.length];
            for (int i = 0; i < ukStrings.length; i++) {
                ukModels[i] = getUnknownModel(ukStrings[i]);
            }
            lm.setUnknownModels(ukModels);
        }

        // import the vocab if it exists
        if (config.getString("vocab") != null) {
            lm.setVocab(SymbolSet.readFromFile(config.getString("vocab")));
            if (debug > 0) {
                System.err.println("CountNgrams, loaded " + lm.getVocab().getSize() + " vocabulary");
            }
        } else if (!loader.supportsReset()) {
            System.err.println("CountNgrams only supports piped input if the vocabulary is specified.");
            System.err.println("Either specify a vocabulary or load the input directly from a file.");
            System.exit(1);
        }

        // train the model
        lm.trainModel(loader);

        if (config.getString("vocabout") != null) {
            lm.getVocab().writeToFile(config.getString("vocabout"), false);
        }

        if (config.getBoolean("ukexpand")) {
            lm.expandUnknowns();
        }

        if (debug > 0) {
            System.err.println("CountNgrams, Started writing");
        }
        long time = System.currentTimeMillis();

        // print the model
        BufferedOutputStream os = new BufferedOutputStream(
                (args.length > 1 ? new FileOutputStream(args[1]) : System.out), 16384
        );

        writer.write(lm, os);
        os.close();

        if (debug > 0) {
            System.err.println("CountNgrams, done writing - " + (System.currentTimeMillis() - time) + " ms");
        }
    }

    public int getLineCountFile(String file) throws IOException {
        BufferedReader buf = new BufferedReader(new FileReader(file));
        String s = "";
        int count = 0;
        while ((s = buf.readLine()) != null) {
            count++;
        }
        buf.close();
        return count;

    }

    // A function to get unknown models
    private static NgramLM getUnknownModel(String str) {

        // get the strings
        String[] strs = str.split(":");
        if (strs.length < 2) {
            System.err.println("Must specify at least a symbol and a vocabulary size for unknown models (e.g. <unk>:5000)");
            System.exit(1);
        }
        // get the model size
        int modelSize = 0;
        try {
            modelSize = Integer.parseInt(strs[1]);
        } catch (NumberFormatException e) {
            System.err.println("Illegal vocabulary size for " + strs[0] + ": " + strs[1] + ". Must be an integer.");
        }
        // get the regex
        String regStr = (strs.length > 2 ? strs[2] : null);
        // get the n-gram order
        int nOrder = 2;
        if (strs.length > 3) {
            try {
                nOrder = Integer.parseInt(strs[3]);
            } catch (NumberFormatException e) {
                System.err.println("Illegal ngram-order size for " + strs[0] + ": " + strs[3] + ". Must be an integer.");
            }
        }
        // load the smoother
        NgramSmoother mySmoother = null;
        String smoothStr = (strs.length > 4 ? strs[4] : "wb");
        if (smoothStr.equals("ml")) {
            mySmoother = new MLSmoother();
        } else if (smoothStr.equals("gt")) {
            mySmoother = new GTSmoother();
        } else if (smoothStr.equals("wb")) {
            mySmoother = new WBSmoother();
        } else if (smoothStr.equals("abs")) {
            mySmoother = new AbsoluteSmoother();
        } else if (smoothStr.equals("mkn")) {
            mySmoother = new MKNSmoother();
        } else if (smoothStr.equals("kn")) {
            mySmoother = new KNSmoother();
        } else {
            System.err.println("Illegal smoother type in unknown model \"" + str + "\"");
            System.exit(1);
        }
        NgramLM ret = new NgramLM(nOrder, mySmoother);
        ret.setSymbol(strs[0]);
        ret.setVocabLimit(modelSize);
        if (regStr != null) {
            ret.setRegex(regStr);
        }
        return ret;
    }

    public static String makeEnt(double all, double simp, double cls, double unk, String unkSym) {
        StringBuffer sb = new StringBuffer();
        sb.append(all);
        if (simp != all) {
            sb.append("(s=");
            sb.append(simp);
            if (cls != 0) {
                sb.append(",c=").append(cls);
            }
            if (unk != 0) {
                sb.append(",u");
                if (unkSym != null) {
                    sb.append('[').append(unkSym).append(']');
                }
                sb.append('=').append(unk);
            }
            sb.append(')');
        }
        return sb.toString();
    }

    

    

    
    
    
    public ArrayList<Double> load(String file, int domain, int iteration, int total_domains) 
            throws FileNotFoundException, IOException, InterruptedException {
        System.out.println("Opening file ... " + file+"_"+domain+"_"+iteration+"_"+total_domains);
        BufferedReader buf = new BufferedReader(new FileReader(file+"_"+domain+"_"+iteration+"_"+total_domains));
        String s = "";
        int count = 0;
        ArrayList<Double> sentProb = new ArrayList<Double>();
        while((s=buf.readLine())!=null) {
            s = s.trim();
            if(s.length()>0) {
                double temp = Double.parseDouble(s);
                sentProb.add(count, temp);
                count++;
            }
        }
        buf.close();
        return sentProb;
    }
    
   
    
    
    public void EM(int iteration, String fileEN, String fileFR, int maximal_ngrams, int domains, int num_of_sents, int total_domains, int threads) throws IOException, Exception {
        ArrayList<ArrayList<Double>> sentenceProbEN = new ArrayList<ArrayList<Double>>(domains);
        PriorSent = new ArrayList<ArrayList<Float>>();
        for (int d = 0; d < domains; d++) {
            PriorSent.add(new ArrayList<Float>());
            sentenceProbEN.add(d, load(fileEN+"."+fileEN, d, iteration, total_domains));
        }
        ArrayList<ArrayList<Double>> sentenceProbFR = new ArrayList<ArrayList<Double>>(domains);
        for (int d = 0; d < domains; d++) {
            sentenceProbFR.add(d, load(fileFR+"."+fileFR, d, iteration, total_domains));
        }
        
        for(int i = 0; i < num_of_sents; i++) {
            double abc[] = new double[domains];        
            double total = 0;
            for(int d = 0; d < domains; d++) {
                //abc[d] = sentenceProbEN.get(d).get(i)*sentenceProbFR.get(d).get(i)*prior.get(d); - I ignore prior ...
                abc[d] = sentenceProbEN.get(d).get(i)*sentenceProbFR.get(d).get(i);
                //System.out.println(abc[d]);
                total += abc[d];
            }
            for(int d = 0; d < domains; d++) {
                float t = (float) (abc[d] / total);
                //System.out.println(t);
                if(t<0.00001f) {
                    t= 0.00001f;
                }
                if(Float.isInfinite(t)) {
                    System.out.println("error Inf .......  "+ t+"~"+abc[d]+"~"+total);
                    t = 0.00001f;
                }
                
                if(Float.isNaN(t)) {
                    System.out.println("error NAN .......  "+ t+"~"+abc[d]+"~"+total);
                    t = 0.00001f;
                }
                
                /*if (i < 102145) { //hardware
                    if (d == 0) {
                        t = 0.9999f;//hardware
                    }
                    if (d != 0) {
                        t = 0.0001f;//hardware
                    }
                }

                if (i >= 102145 && i < 200812) { //legal
                    if (d == 1) {
                        t = 0.9999f;//legal
                    }
                    if (d != 1) {
                        t = 0.0001f;//legal
                    }
                }

                if (i >= 200812 && i < 304626) { //pharmacy
                    if (d == 2) {
                        t = 0.9999f;//pharmacy
                    }
                    if (d != 2) {
                        t = 0.0001f;//pharmacy
                    }
                }*/
                        
                PriorSent.get(d).add(0.0f);
                PriorSent.get(d).set(i, t);                
            }
        }
        //M-step ....
        for (int d = 0; d < domains; d++) {
            FileWriter fi_w = new FileWriter("fractionCounts_" + 
                    d +"_iteration_"+(iteration)+"totaldomains_"+total_domains);
            for (int i = 0; i < PriorSent.get(0).size(); i++) {
                fi_w.write((PriorSent.get(d).get(i)) + "\n");
            }
            fi_w.close();
        }
        writedownPerpl("en.output", iteration, domains, threads);
        writedownPerpl("fr.output", iteration, domains, threads);        
        MStepForPrior(domains, num_of_sents, iteration);
    }
    public void writedownPerpl(String file, int iteration, int number_of_domains, int threads) throws IOException, Exception {

        
        final ExecutorService executor = Executors.newFixedThreadPool(threads);
        final List<Callable<Object>> tasks = new ArrayList<Callable<Object>>();

        for (int i = 0; i < number_of_domains; i++) {
            String parameter = "./acl_kneserney lm -train -i=./"+file+" -order=3 -interpolate -o="+file+".ournew_"
                    + i + "_iteration_" + (iteration) + "totaldomains_" + number_of_domains
                    + " -w=fractionCounts_" + i + "_iteration_" + (iteration) + "totaldomains_" + number_of_domains;
            System.out.println(parameter);
            tasks.add(Executors.callable(new DataProcessorMain(parameter)));
        }
        executor.invokeAll(tasks);
        executor.shutdown();  // not really necessary if the executor goes out of scope.
        System.out.println("Finished all threads");
    }
}
