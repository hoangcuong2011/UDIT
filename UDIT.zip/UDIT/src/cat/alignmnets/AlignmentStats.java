package cat.alignmnets;


import java.io.IOException;
import cat.corpus.BilingualCorpus;
import gnu.trove.map.hash.TIntIntHashMap;
import gnu.trove.map.hash.TIntObjectHashMap;

// Number of aligned poitns
// %aligned points vs sentence len
// Number of unaligned source words
// Number of unaligned foreign words

public class AlignmentStats {

	public static void printAlignmentStats(AlignmentsSet set) {
		int nrAlignedPoints = 0;
		double avgAlignedPoints = 0;

		int unalignedForeignWords = 0;
		int unalignedSourceWords = 0;
		int totalOfForeingWords = 0;
		int totalOfSourceWords = 0;
		int nrSentences = 0;
		for (Alignment a : set._alignments) {
			totalOfForeingWords += a.getForeignLenght();
			totalOfSourceWords += a.getSourceLenght();
			int alignedPoints = a.numberOfAlignedPoints();
			avgAlignedPoints += alignedPoints * 1.0 / a.getForeignLenght();
			nrAlignedPoints += alignedPoints;
			unalignedForeignWords += a.getNumberOfForeignNotAligned();
			unalignedSourceWords += a.getNumberOfSourceNotAligned();
			nrSentences++;
		}

		System.out.println("Total of points " + nrAlignedPoints);
		System.out.println("Avg of points " + avgAlignedPoints * 1.0
				/ nrSentences);
		System.out.println("Unaligned Source Words " + unalignedSourceWords
				* 1.0 / nrSentences);
		System.out.println("Unaligned Foreign Words " + unalignedForeignWords
				* 1.0 / nrSentences);
	}

	public static void statsByLen(AlignmentsSet set) {
		AlignmentsSet[] sets = set.splitBySentenceLen();
		for (int i = 0; i < sets.length; i++) {
			System.out.println(sets[i].numberOfAlignedPoints() + " "
					+ sets[i].numberOfSourceUnaligned());

		}
	}

	
	public static boolean positionValid(Alignment al, int sourceIndex, int foreignIndex, boolean all, boolean sure){
		if(all){
			return al.hasPosition(sourceIndex, foreignIndex);
		}else if(sure){
			return al.isSure(sourceIndex, foreignIndex);
		}else{
			return al.isPossible(sourceIndex, foreignIndex);
		}
	}
	
	public static void numberOfPhrases(Alignment a, TIntObjectHashMap<TIntIntHashMap> phrases, boolean all, boolean sure){
		int sourceLen = a.getSourceLenght();
		int foreignLen = a.getForeignLenght();
		for(int sourceStartIndex = 0; sourceStartIndex < sourceLen;){
			for(int foreignStartIndex = 0; foreignStartIndex < foreignLen;){				
				if(positionValid(a,sourceStartIndex, foreignStartIndex,all,sure)){
					int sourceEndIndex;
					int foreignEndIndex;
					for(sourceEndIndex = sourceStartIndex;sourceEndIndex<sourceLen;sourceEndIndex++){
						if(!positionValid(a,sourceEndIndex,foreignStartIndex,all,sure)){
							break;
						}
					}
					for(foreignEndIndex = foreignStartIndex;foreignEndIndex< foreignLen; foreignEndIndex++){
						if(!positionValid(a,sourceStartIndex,foreignEndIndex,all,sure)){
							break;
						}
					}
					int sourcePhraseLen = (sourceEndIndex-sourceStartIndex);
					int foreignPhraseLen = (foreignEndIndex-foreignStartIndex);
				//	System.out.println("Found phrase from " + sourceStartIndex + ":" + (sourceEndIndex-1) + "-" + foreignStartIndex + ":" + (foreignEndIndex-1));
					if(phrases.contains(sourcePhraseLen)){
						TIntIntHashMap is = phrases.get(sourcePhraseLen);
						if(is.contains(foreignPhraseLen)){
							is.put(foreignPhraseLen,is.get(foreignPhraseLen)+1);
						}else{
							is.put(foreignPhraseLen, 1);
						}
					}else{
						TIntIntHashMap is = new TIntIntHashMap();
						is.put(foreignPhraseLen, 1);
						phrases.put(sourcePhraseLen, is);
					}
					sourceStartIndex=sourceEndIndex-1;
					foreignStartIndex=foreignEndIndex-1;
				}
				foreignStartIndex++;
			}
			sourceStartIndex++;
		}
	}
	
	public static TIntObjectHashMap<TIntIntHashMap> numberOfPhrases(AlignmentsSet set, boolean all, boolean sure){
		TIntObjectHashMap<TIntIntHashMap> phrases = new TIntObjectHashMap<TIntIntHashMap>();
		for(int i = 0; i < set._alignments.size(); i++){
			Alignment al = set.get(i);
			numberOfPhrases(al, phrases, all, sure);
		}
		return phrases;
	}
	
	public static void printPhrases(AlignmentsSet set,boolean all, boolean sure){
		TIntObjectHashMap<TIntIntHashMap> phrases = numberOfPhrases(set,all,sure);
		System.out.println("slen | tlen | counts");
		for(int i = 0; i < phrases.keys().length;i++){
			TIntIntHashMap is = phrases.get(phrases.keys()[i]);
			for(int j = 0; j < is.keys().length; j++){
				//System.out.println("Phrases of source len " + phrases.keys()[i] + " foreing len of " + is.keys()[j] + " has " +is.get(is.keys()[j]) + " counts");
				System.out.println(phrases.keys()[i] + "\t" + is.keys()[j] + "\t" +is.get(is.keys()[j]));
			}
		}
	}
	
	public static void main(String[] args) throws IOException {
		BilingualCorpus corpus = BilingualCorpus.getCorpusFromFileDescription(args[0], 5000,40);
		AlignmentsSet set = corpus.getGold();
		//statsByLen(set);
		/*AlignmentsSet set = new AlignmentsSet();
		Alignment a2 = new Alignment(0, (byte) 0, 4, 5);
		a2.add(0, 0);
		a2.add(1, 1);
		a2.add(1, 2);
		a2.add(2, 1);
		a2.add(2, 2);
		a2.add(3, 1);
		a2.add(3, 2);
		a2.add(0, 3);
		a2.add(0, 4);
		for(int sourcePosition = 0; sourcePosition <4; sourcePosition++){
			for(int foreingPosition = 0; foreingPosition <5; foreingPosition++){
				System.out.print(" " + a2._alignment[sourcePosition][foreingPosition]);
			}
			System.out.println();
		}
		set.addAlignment(a2);
		set.addAlignment(a2);*/
		System.out.println("max source len " + corpus.getMaxSourceLen());
		System.out.println("max foreign len " + corpus.getMaxForeignLen());
		TIntObjectHashMap<TIntIntHashMap> phrases = numberOfPhrases(set,false,false	);
		for(int i = 0; i < phrases.keys().length;i++){
			TIntIntHashMap is = phrases.get(phrases.keys()[i]);
			for(int j = 0; j < is.keys().length; j++){
				//System.out.println("Phrases of source len " + phrases.keys()[i] + " foreing len of " + is.keys()[j] + " has " +is.get(is.keys()[j]) + " counts");
				System.out.println(phrases.keys()[i] + "\t" + is.keys()[j] + "\t" +is.get(is.keys()[j]));
			}
		}
	}
}
