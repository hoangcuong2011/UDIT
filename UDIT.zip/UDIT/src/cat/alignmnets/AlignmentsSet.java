package cat.alignmnets;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import cat.alignmnets.output.AlignerOutput;
import cat.common.Pair;
import cat.corpus.BilingualCorpus;

public class AlignmentsSet {
	public ArrayList<Alignment> _alignments;

	public AlignmentsSet() {
		_alignments = new ArrayList<Alignment>();
	}

	public AlignmentsSet(ArrayList<Alignment> alignments) {
		_alignments = alignments;
	}

	/*
	 * public AlignmentsSet(String file, byte sentenceSource, BilingualCorpus
	 * corpus) throws IOException{ this(file, sentenceSource,corpus,0); }
	 */

	public static AlignmentsSet getAlignmentFromMoses(String file,
			byte sentenceSource, BilingualCorpus corpus) throws IOException {
		AlignmentsSet set = new AlignmentsSet();
		set._alignments = new ArrayList<Alignment>();
		Alignment gold = null;
		int sentenceNr = 0;
		BufferedReader input = new BufferedReader(new InputStreamReader(
				new FileInputStream(file)));
		String line = input.readLine();
		while ((line != null)) {
			gold = new Alignment(sentenceNr, sentenceSource, corpus
					.getSourceSentenceLength(sentenceNr, sentenceSource),
					corpus.getForeignSentenceLength(sentenceNr, sentenceSource));
			// System.out.println(line);
			// System.out.println(corpus.getSourceSentenceString(sentenceNr,
			// sentenceSource));
			// System.out.println(corpus.getForeignSentenceString(sentenceNr,
			// sentenceSource));
			String[] fields = line.split(" ");
			for (int i = 0; i < fields.length; i++) {
				String pos[] = fields[i].split("-");
				gold.add(Integer.parseInt(pos[1]), Integer.parseInt(pos[0]));
			}
			line = input.readLine();
			set._alignments.add(gold);
			sentenceNr++;
		}
		System.out.println("Finish Building Alignments Set");
		return set;
	}

	public static AlignmentsSet getAlignmentFromFileNAACL(String file,
			byte sentenceSource, BilingualCorpus corpus,
			int initialSentenceNumber) throws IOException {
		AlignmentsSet set = new AlignmentsSet();
		set._alignments = new ArrayList<Alignment>();
		Alignment gold = null;
		int sentenceNumber = initialSentenceNumber;
		int number;
		BufferedReader input = new BufferedReader(new InputStreamReader(
				new FileInputStream(file)));
		String line = input.readLine();
		while ((line != null)) {

			String[] fields = line.split(" ");
			number = Integer.parseInt(fields[0]);
			// System.out.println(corpus.getSourceSentenceString(number,
			// sentenceSource));
			// System.out.println(corpus.getForeignSentenceString(number,
			// sentenceSource));

			// System.out.println(number +" " + sentenceNumber);
			if (number < sentenceNumber) {
				// System.out.println("Ignoring alignmnet for sentence " +
				// number);
				line = input.readLine();
				continue; // we don't want to see this
			}
			if (number != sentenceNumber) {
				// System.out.println("Reading new line");
				if (gold != null) {
					set._alignments.add(gold);
				}
				sentenceNumber = number;
				// System.out.println("SentenceNumber" + (sentenceNumber-1) + "
				// " + corpus.getSourceSentenceLength(sentenceNumber-1 ,
				// sentenceSource)+ " " +
				// corpus.getForeignSentenceLength(sentenceNumber-1,
				// sentenceSource));
				gold = new Alignment(sentenceNumber - 1, sentenceSource, corpus
						.getSourceSentenceLength(sentenceNumber - 1,
								sentenceSource), corpus
						.getForeignSentenceLength(sentenceNumber - 1,
								sentenceSource));
			}
			if (gold == null) {
				gold = new Alignment(sentenceNumber - 1, sentenceSource, corpus
						.getSourceSentenceLength(sentenceNumber - 1,
								sentenceSource), corpus
						.getForeignSentenceLength(sentenceNumber - 1,
								sentenceSource));
			}
			int sindex = Integer.parseInt(fields[1]);
			int findex = Integer.parseInt(fields[2]);
			byte type;
			// If there is no field aligment is Sure (according to EPPS)
			if (fields.length == 4 && fields[3].equals("P"))
				type = 1;
			else
				type = 2;
			// System.out.print(corpus.getSourceWord((sentenceNumber-1),
			// sentenceSource, sindex-1) +" ");
			// System.out.println(corpus.getForeignWord((sentenceNumber-1),
			// sentenceSource, findex-1) + "\n");
			// System.out.println((sentenceNumber-1) + "sIndex " + sindex + "
			// fIndex " + findex +" type " + type);
			gold.add(sindex - 1, findex - 1, type);
                        System.out.println(line);
			line = input.readLine();
		}
		set._alignments.add(gold); // Catch last alignment
		System.out.println("Finish Building Alignments Set");
		return set;
	}

	public void addAlignment(Alignment al) {
		_alignments.add(al);
	}

	public Alignment get(int number) {
		return _alignments.get(number);
	}

	public AlignmentsSet reverse() {
		AlignmentsSet reversed = new AlignmentsSet();
		ArrayList<Alignment> goldsR = new ArrayList<Alignment>();
		for (Alignment gold : _alignments) {
			goldsR.add(gold.reverse());
		}
		reversed._alignments = goldsR;
		return reversed;
	}

	public int size() {
		return _alignments.size();
	}

	public ArrayList<Alignment> getAlignments() {
		return _alignments;
	}

	public Alignment getAlignmentByPos(int pos) {
		return _alignments.get(pos);
	}

	/*
	 * public HashMap<Integer,Float> nullAlignedBySentenceLenght(){ HashMap<Integer,Float>
	 * nullAligned = new HashMap<Integer,Float>(); HashMap<Integer,Integer>
	 * nrSentences = new HashMap<Integer,Integer>(); for(Alignment gold:
	 * _alignments){ int lenght = gold.getForeignLenght(); float nrNull =
	 * gold.getNumberNulls(); if(nullAligned.containsKey(lenght)){ nrNull +=
	 * nullAligned.get(lenght);
	 * nrSentences.put(lenght,1+nrSentences.get(lenght)); }else{
	 * nrSentences.put(lenght,1); } nullAligned.put(lenght, nrNull); }
	 * for(Integer i: nullAligned.keySet()){ nullAligned.put(i,
	 * nullAligned.get(i)/nrSentences.get(i)); } return nullAligned; }
	 */

	public void outputWithStatistics(BilingualCorpus corpus, PrintStream out,
			int maxNumber) throws UnsupportedEncodingException {
		ArrayList<Pair<Integer, Integer>> mask = new ArrayList<Pair<Integer, Integer>>();
		mask.add(new Pair<Integer, Integer>(-1, -1));
		mask.add(new Pair<Integer, Integer>(-1, 0));
		mask.add(new Pair<Integer, Integer>(0, -1));
		mask.add(new Pair<Integer, Integer>(0, 1));
		mask.add(new Pair<Integer, Integer>(1, 0));
		mask.add(new Pair<Integer, Integer>(1, 1));
		mask.add(new Pair<Integer, Integer>(-1, 1));
		mask.add(new Pair<Integer, Integer>(1, -1));

		double numberalignedPoints = 0;
		double numberSurePoints = 0;
		double numberPossiblePoints = 0;
		double distanceToDiagonal = 0;
		double meanFertility = 0;

		int i = 1;

		for (Alignment a : getAlignments()) {
			if (i <= maxNumber) {
				out.println("Gold Alignments " + i);
				AlignerOutput.outputGold(a, corpus, out);
				out.println(" Source Len" + a.getSourceLenght()
						+ " Foreign len " + a.getForeignLenght());
				int nAlignedPoints = a.numberOfAlignedPoints();
				int nSureAligedPoints = a.numberOfAlignedPoints(2);
				int nPossibleAligedPoints = a.numberOfAlignedPoints(1);
				numberalignedPoints += nAlignedPoints;
				numberSurePoints += nSureAligedPoints;
				numberPossiblePoints += nPossibleAligedPoints;
				distanceToDiagonal += a.distanceToDiagonal();
				meanFertility += a.meanFertility();
				out.println(" number of aligned points: " + nAlignedPoints
						+ " %sure " + nSureAligedPoints * 1.0 / nAlignedPoints
						+ " % possible " + nPossibleAligedPoints * 1.0
						/ nAlignedPoints);
				out.println(" number of lonely points: "
						+ a.numberOfLonelyPoints(mask));
				out.println(" nmean fertility: " + a.meanFertility());
				out.println(" distance to diagonal: " + a.distanceToDiagonal());
				out.println();
				out.println();
				i++;
			}
		}
		out.println("TOTAL CORPUS");
		out.println(" nmean fertility: " + meanFertility
				/ getAlignments().size());
		out.println(" number of aligned points: " + numberalignedPoints
				+ " %sure " + numberSurePoints * 1.0 / numberalignedPoints
				+ " % possible " + numberPossiblePoints * 1.0
				/ numberalignedPoints);
		out.println(" distance to diagonal: " + distanceToDiagonal / i);
	}

	public void outputWithStatistics(BilingualCorpus corpus, PrintStream out)
			throws UnsupportedEncodingException {
		outputWithStatistics(corpus, out, Integer.MAX_VALUE);
	}

	public int numberOfAlignedPoints() {
		int number = 0;
		for (Alignment al : _alignments) {
			number += al.numberOfAlignedPoints();
		}
		return number;
	}

	public int numberOfSourceUnaligned() {
		int number = 0;
		for (Alignment al : _alignments) {
			number += al.getNumberOfSourceNotAligned();
		}
		return number;
	}

	public AlignmentsSet[] splitBySentenceLen() {
		int nrBins = 5;
		AlignmentsSet[] sets = new AlignmentsSet[nrBins];
		for (int i = 0; i < nrBins; i++) {
			sets[i] = new AlignmentsSet();
		}
		for (int i = 0; i < _alignments.size(); i++) {
			Alignment al = _alignments.get(i);
			if (al._foreignLen < 10) {
				sets[0].addAlignment(al);
			} else if (al._foreignLen < 20) {
				sets[1].addAlignment(al);
			} else if (al._foreignLen < 30) {
				sets[2].addAlignment(al);
			} else if (al._foreignLen < 40) {
				sets[3].addAlignment(al);
			} else {
				sets[4].addAlignment(al);
			}
		}
		return sets;
	}

	public static void main(String[] args) throws IOException {

		BilingualCorpus corpus = new BilingualCorpus(10000, "test", "-", "-");
		corpus.addTestFile(args[0], args[1]);
		corpus.addGoldAligments(args[2]);
		AlignmentsSet g = corpus.getGold();
		g.outputWithStatistics(corpus, System.out, 100);

		/*
		 * "/scratch/graca/mwa/Manual-Alignemts/working-corpus/100.en"
		 * "/scratch/graca/mwa/Manual-Alignemts/working-corpus/100.es"
		 * "/scratch/graca/mwa/Manual-Alignemts/working-corpus/100.pt"
		 * "/scratch/graca/mwa/Manual-Alignemts/working-corpus/100.fr"
		 * 
		 * "/scratch/graca/mwa/Manual-Alignemts/working-corpus/e-es/e-es-100.wa"
		 * "/scratch/graca/mwa/Manual-Alignemts/working-corpus/e-pt/e-pt-100.wa"
		 * "/scratch/graca/mwa/Manual-Alignemts/working-corpus/e-fr/e-fr-100.wa"
		 * "/scratch/graca/mwa/Manual-Alignemts/working-corpus/pt-es/pt-es-100.wa"
		 * "/scratch/graca/mwa/Manual-Alignemts/working-corpus/pt-fr/pt-fr-100.wa"
		 * "/scratch/graca/mwa/Manual-Alignemts/working-corpus/es-fr/es-fr-100.wa"
		 */

		// corpus.addTestFile("/scratch/graca/data/naacl2003/English-French/test/test-final-347.e","/scratch/graca/data/naacl2003/English-French/test/test-final-347.f");

		// corpus.addGoldAligments("/Users/javg/Projects/Word Alignments
		// Algorithms/hansardslx/test/test.wa.nonullalign-347");
		// corpus.addGoldAligments("/scratch/graca/data/naacl2003/English-French/answers/test.wa.nonullalign-347");

		/*
		 * Corpus source = new Corpus(Corpora.EPPS_EUROPARL_ENGLISH_TEST_FILE);
		 * Corpus foreign = new Corpus(Corpora.EPPS_EUROPARL_SPANISH_TEST_FILE);
		 * GoldAlignmentsSet set = new
		 * GoldAlignmentsSet(Corpora.EPPS_ENGLISH_SPANISH_GOLD_ALIGMENTS,source,foreign);
		 *  /* Corpus source = new Corpus(Corpora.HANSARDS_ENGLISH_TEST_FILE);
		 * Corpus foreign = new Corpus(Corpora.HANSARDS_FRENCH_TEST_FILE);
		 * GoldAlignmentsSet set = new
		 * GoldAlignmentsSet(Corpora.HANSARDS_ENGLISH_FRENCH_GOLD_ALIGMENTS,source,foreign);
		 */
		/*
		 * HashMap<Integer,Float> nulls = set.nullAlignedBySentenceLenght();
		 * for(Integer i: nulls.keySet()){ System.out.println("sentence Lenght " +
		 * i + " NR null " + nulls.get(i)); }
		 */
		/*
		 * AlignerOutput out = new AlignerOutput(); for(GoldAlignment g:
		 * set.getAlignments()){ out.outputGold(g, System.out); }
		 */

		/*
		 * GoldAlignment g = set.getAlignments().get(0); //for(GoldAlignment g:
		 * set.getAlignments()){ out.outputGold(g, System.out); //}
		 */

	}
}
