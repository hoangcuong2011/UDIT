/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.programs;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hoangcuong2011
 */

class DataProcessor implements Runnable {
    String text;
    public DataProcessor(String text){
        this.text = text;
    }
 
    @Override
    public void run() {
        try {
            //System.out.println("Processing data: " + data);
            
            runCommand("java -Xmx250g -cp trove-3.0.3.jar:UDIT.jar"
                    + " cat.programs.LoadSentPrior "
                    + text); 
            //System.out.println(text);
            // Data processing goes here
        } catch (IOException ex) {
            ex.printStackTrace();
            Logger.getLogger(DataProcessor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
            Logger.getLogger(DataProcessor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void runCommand(String command) throws IOException, InterruptedException {
        int count = 0;
        Process p = Runtime.getRuntime().exec(command);

        BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));

        BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));

        // read the output from the command
        String s = "";
        while ((s = stdInput.readLine()) != null) {
            System.out.println(s);
        }
        while ((s = stdError.readLine()) != null) {
            System.out.println(s);
        }
        try {
            int exitVal = p.waitFor();
            System.out.println("Done Controller");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        count++;
    }

}
public class PLSA {

    /**
     * @param args the command line arguments
     */
    
    ArrayList<Double> domainPrior = null;
    ArrayList<ArrayList<Double>> enStringprior = null;
    ArrayList<ArrayList<Double>> frStringprior = null;
    ArrayList<ArrayList<Double>> enStringpriorNorm = null;
    ArrayList<ArrayList<Double>> frStringpriorNorm = null;
    
    public static void main(String[] args) throws InterruptedException, IOException {
        // TODO code application logic here
        
        int times = Integer.parseInt(args[0]);
        int number_of_domains = Integer.parseInt(args[1]);
        int threads = Integer.parseInt(args[2]);
        String priorFile = "prior_"+times+"_domains"+number_of_domains;
        
        PLSA program = new PLSA();

        final ExecutorService executor = Executors.newFixedThreadPool(threads);
        final List<Callable<Object>> tasks = new ArrayList<Callable<Object>>();

        for (int d = 0; d < number_of_domains; d++) {
            String file = "fr.output";
            String parameter = "fr.output " + d + " " + times + " " + number_of_domains + " " + file;
            tasks.add(Executors.callable(new DataProcessor(parameter)));

            file = "en.output";
            parameter = "en.output " + d + " " + times + " " + number_of_domains + " " + file;
            tasks.add(Executors.callable(new DataProcessor(parameter)));
        }

        executor.invokeAll(tasks);
        executor.shutdown();  // not really necessary if the executor goes out of scope.
        System.out.println("Finished all threads");
        
        
        program.domainPrior = program.loadDomainPrior(priorFile);
        program.enStringprior = 
                program.loadStringPrior("en.output", number_of_domains);
        program.frStringprior = 
                program.loadStringPrior("fr.output", number_of_domains);
        program.loadEnFrStringPriorwithNorm(number_of_domains);        
        program.loadEnStringPriorwithNorm(number_of_domains);        
        program.loadFrStringPriorwithNorm(number_of_domains);     
        
        
    }
    
    
    public ArrayList<ArrayList<Double>> loadEnFrStringPriorwithNorm(int total_domains) throws FileNotFoundException, IOException {
        ArrayList<ArrayList<Double>> StringpriorwithNorm = new ArrayList<ArrayList<Double>>();
        ArrayList<Double> normalization = new ArrayList<Double>();
        int totalLines = getLineCountFile("en.output");//fixed
        for(int i = 0; i < totalLines; i++) {
            normalization.add(0.0);
        }
        for (int d = 0; d < total_domains; d++) {
            StringpriorwithNorm.add( new ArrayList<Double>());
        }
        for (int i = 0; i < totalLines; i++) {
            for (int d = 0; d < total_domains; d++) {
                double temp = domainPrior.get(d) * enStringprior.get(d).get(i) * frStringprior.get(d).get(i);
                if (temp < 1E-200) {
                    temp = 1E-200;
                }
                StringpriorwithNorm.get(d).add(i, temp);
                normalization.set(i, normalization.get(i) + temp);
            }
        }
        for(int i = 0; i < StringpriorwithNorm.get(0).size(); i++) {            
            for(int d = 0; d < total_domains; d++) {
                double abc = StringpriorwithNorm.get(d).get(i)/normalization.get(i);
                
                /*if (i < 102145) { //hardware
                    if (d == 0) {
                        abc = 0.9999;//hardware
                    }
                    if (d != 0) {
                        abc = 0.0001;//hardware
                    }
                }

                if (i >= 102145 && i < 200812) { //legal
                    if (d == 1) {
                        abc = 0.9999;//legal
                    }
                    if (d != 1) {
                        abc = 0.0001;//legal
                    }
                }

                if (i >= 200812 && i < 304626) { //pharmacy
                    if (d == 2) {
                        abc = 0.9999;//pharmacy
                    }
                    if (d != 2) {
                        abc = 0.0001;//pharmacy
                    }
                }*/
                
                if(abc<0.00001)
                    abc = 0.00001;
                StringpriorwithNorm.get(d).set(i, abc);
            }
            
        }
        FileWriter fi_w[] = new FileWriter[total_domains];
        for (int d = 0; d < total_domains; d++) {
            fi_w[d] = new FileWriter("ENFRStringpriorwithNorm_" + d);
            for(int i = 0; i < totalLines; i++) {
                fi_w[d].write(StringpriorwithNorm.get(d).get(i)+"\n");
            }
            fi_w[d].close();
        }
        
        return StringpriorwithNorm;

    }
    
    public ArrayList<ArrayList<Double>> loadStringPrior(String en_or_fr, int total_domains) throws FileNotFoundException, IOException {
        ArrayList<ArrayList<Double>> Stringprior = new ArrayList<ArrayList<Double>>();
        for (int d = 0; d < total_domains; d++) {
            Stringprior.add( new ArrayList<Double>());
            BufferedReader buf = new BufferedReader(new FileReader(en_or_fr + "_" + d + "_" + total_domains));
            String s = "";
            int count = 0;
            while ((s = buf.readLine()) != null) {
                Stringprior.get(d).add(count, Double.parseDouble(s.trim()));
                count++;
            }
            buf.close();
        }
        return Stringprior;

    }
    
    public ArrayList<Double> loadDomainPrior(String file) throws FileNotFoundException, IOException {
        ArrayList<Double> Stringprior = new ArrayList<Double>();
        BufferedReader buf = new BufferedReader(new FileReader(file));
        String s = "";
        int count = 0;
        while ((s = buf.readLine()) != null) {
            Stringprior.add(count, Double.parseDouble(s.trim()));
            count++;
        }
        buf.close();
        return Stringprior;

    }
    
    
    public int getLineCountFile(String file) throws IOException {
        BufferedReader buf = new BufferedReader(new FileReader(file));
        String s = "";
        int count = 0;
        while ((s = buf.readLine()) != null) {
            count++;
        }
        buf.close();
        return count;

    }
    
   
    public ArrayList<ArrayList<Double>> loadEnStringPriorwithNorm(int total_domains) throws FileNotFoundException, IOException {
        ArrayList<ArrayList<Double>> StringpriorwithNorm = new ArrayList<ArrayList<Double>>();
        ArrayList<Double> normalization = new ArrayList<Double>();
        int totalLines = getLineCountFile("en.output");//fixed
        for(int i = 0; i < totalLines; i++) {
            normalization.add(0.0);
        }
        for (int d = 0; d < total_domains; d++) {
            StringpriorwithNorm.add( new ArrayList<Double>());
        }
        for (int i = 0; i < totalLines; i++) {
            for (int d = 0; d < total_domains; d++) {
                double temp = domainPrior.get(d) * enStringprior.get(d).get(i);
                if (temp < 1E-200) {
                    temp = 1E-200;
                }
                StringpriorwithNorm.get(d).add(i, temp);
                normalization.set(i, normalization.get(i) + temp);
            }
        }
        for(int i = 0; i < StringpriorwithNorm.get(0).size(); i++) {            
            for(int d = 0; d < total_domains; d++) {
                double abc = StringpriorwithNorm.get(d).get(i)/normalization.get(i);
                
                /*if (i < 102145) { //hardware
                    if (d == 0) {
                        abc = 0.9999;//hardware
                    }
                    if (d != 0) {
                        abc = 0.0001;//hardware
                    }
                }

                if (i >= 102145 && i < 200812) { //legal
                    if (d == 1) {
                        abc = 0.9999;//legal
                    }
                    if (d != 1) {
                        abc = 0.0001;//legal
                    }
                }

                if (i >= 200812 && i < 304626) { //pharmacy
                    if (d == 2) {
                        abc = 0.9999;//pharmacy
                    }
                    if (d != 2) {
                        abc = 0.0001;//pharmacy
                    }
                }*/
                
                if(abc<0.00001)
                    abc = 0.00001;
                StringpriorwithNorm.get(d).set(i, abc);
            }
            
        }
        FileWriter fi_w[] = new FileWriter[total_domains];
        for (int d = 0; d < total_domains; d++) {
            fi_w[d] = new FileWriter("ENStringpriorwithNorm_" + d);
            for(int i = 0; i < totalLines; i++) {
                fi_w[d].write(StringpriorwithNorm.get(d).get(i)+"\n");
            }
            fi_w[d].close();
        }        
        return StringpriorwithNorm;
    }
        
    public ArrayList<ArrayList<Double>> loadFrStringPriorwithNorm(int total_domains) throws FileNotFoundException, IOException {
        ArrayList<ArrayList<Double>> StringpriorwithNorm = new ArrayList<ArrayList<Double>>();
        ArrayList<Double> normalization = new ArrayList<Double>();
        int totalLines = getLineCountFile("fr.output");//fixed
        for(int i = 0; i < totalLines; i++) {
            normalization.add(0.0);
        }
        for (int d = 0; d < total_domains; d++) {
            StringpriorwithNorm.add( new ArrayList<Double>());
        }
        for (int i = 0; i < totalLines; i++) {
            for (int d = 0; d < total_domains; d++) {
                double temp = domainPrior.get(d) * frStringprior.get(d).get(i);
                if (temp < 1E-200) {
                    temp = 1E-200;
                }
                StringpriorwithNorm.get(d).add(i, temp);
                normalization.set(i, normalization.get(i) + temp);
            }
        }
        for(int i = 0; i < StringpriorwithNorm.get(0).size(); i++) {            
            for(int d = 0; d < total_domains; d++) {
                double abc = StringpriorwithNorm.get(d).get(i)/normalization.get(i);
                
                /*if (i < 102145) { //hardware
                    if (d == 0) {
                        abc = 0.9999;//hardware
                    }
                    if (d != 0) {
                        abc = 0.0001;//hardware
                    }
                }

                if (i >= 102145 && i < 200812) { //legal
                    if (d == 1) {
                        abc = 0.9999;//legal
                    }
                    if (d != 1) {
                        abc = 0.0001;//legal
                    }
                }

                if (i >= 200812 && i < 304626) { //pharmacy
                    if (d == 2) {
                        abc = 0.9999;//pharmacy
                    }
                    if (d != 2) {
                        abc = 0.0001;//pharmacy
                    }
                }*/
                
                
                if(abc<0.00001)
                    abc = 0.00001;
                StringpriorwithNorm.get(d).set(i, abc);
            }
            
        }
        FileWriter fi_w[] = new FileWriter[total_domains];
        for (int d = 0; d < total_domains; d++) {
            fi_w[d] = new FileWriter("FRStringpriorwithNorm_" + d);
            for(int i = 0; i < totalLines; i++) {
                fi_w[d].write(StringpriorwithNorm.get(d).get(i)+"\n");
            }
            fi_w[d].close();
        }
        
        return StringpriorwithNorm;

    }
}
