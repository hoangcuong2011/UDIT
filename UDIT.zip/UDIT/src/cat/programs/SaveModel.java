package cat.programs;

import java.io.FileNotFoundException;
import java.io.IOException;

import cat.common.StaticTools;
import cat.corpus.BilingualCorpus;
import cat.models.HMM;
import cat.models.M1;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * class to train and save an (HMM) alignment model
 */
public class SaveModel {

    double SMALLEST_VALUE = 1E-200;

    public ArrayList<ArrayList<Double>> loadDouble(int number_of_domains, String filename) throws FileNotFoundException, IOException {
        ArrayList<ArrayList<Double>> pd1_sents = new ArrayList<ArrayList<Double>>();
        for (int domain = 0; domain < number_of_domains; domain++) {
            pd1_sents.add(domain, new ArrayList<Double>());
        }
        for (int domain = 0; domain < number_of_domains; domain++) {
            BufferedReader buf = new BufferedReader(new FileReader(filename + "_" + domain));
            String s = "";
            int index = 0;
            while ((s = buf.readLine()) != null) {
                double tmp = Double.parseDouble(s);
                pd1_sents.get(domain).add(index, tmp);
                index++;
            }
            buf.close();
        }
        return pd1_sents;
    }

    public ArrayList<ArrayList<Float>> loadFloat(int number_of_domains, String filename) throws FileNotFoundException, IOException {
        ArrayList<ArrayList<Float>> pd1_sents = new ArrayList<ArrayList<Float>>();
        for (int domain = 0; domain < number_of_domains; domain++) {
            pd1_sents.add(domain, new ArrayList<Float>());
        }
        for (int domain = 0; domain < number_of_domains; domain++) {
            BufferedReader buf = new BufferedReader(new FileReader(filename + "_" + domain));
            String s = "";
            int index = 0;
            while ((s = buf.readLine()) != null) {
                float tmp = Float.parseFloat(s);
                if (tmp < 0.00001f) {
                    tmp = 0.00001f;
                }
                pd1_sents.get(domain).add(index, tmp);
                index++;
            }
            buf.close();
        }
        return pd1_sents;
    }

    public ArrayList<ArrayList<Double>> loadStringPrior(String en_or_fr, int total_domains) throws FileNotFoundException, IOException {
        ArrayList<ArrayList<Double>> Stringprior = new ArrayList<ArrayList<Double>>();
        for (int d = 0; d < total_domains; d++) {
            Stringprior.add(new ArrayList<Double>());
            BufferedReader buf = new BufferedReader(new FileReader(en_or_fr + "_" + d + "_" + total_domains));
            String s = "";
            int count = 0;
            while ((s = buf.readLine()) != null) {
                Stringprior.get(d).add(count, Double.parseDouble(s.trim()));
                count++;
            }
            buf.close();
        }
        return Stringprior;

    }

    public ArrayList<Double> loadDomainPrior(String file) throws FileNotFoundException, IOException {
        ArrayList<Double> Stringprior = new ArrayList<Double>();
        BufferedReader buf = new BufferedReader(new FileReader(file));
        String s = "";
        int count = 0;
        while ((s = buf.readLine()) != null) {
            Stringprior.add(count, Double.parseDouble(s.trim()));
            count++;
        }
        buf.close();
        return Stringprior;

    }

    public void runCommand(String command) throws IOException, InterruptedException {
        int count = 0;
        Process p = Runtime.getRuntime().exec(command);

        BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));

        BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));

        // read the output from the command
        String s = "";
        while ((s = stdInput.readLine()) != null) {
            System.out.println(s);
        }
        while ((s = stdError.readLine()) != null) {
            System.out.println(s);
        }
        try {
            int exitVal = p.waitFor();
            System.out.println("Done Controller");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        count++;
    }

    public ArrayList<ArrayList<Float>> loadPDSent(String file, int total) throws IOException {
        ArrayList<ArrayList<Float>> prior = new ArrayList<ArrayList<Float>>();
        for (int i = 0; i < total; i++) {
            prior.add(new ArrayList<Float>());
        }
        BufferedReader buf = new BufferedReader(new FileReader(file));
        String s = "";
        float d = 0.0f;
        int count = 0;
        while ((s = buf.readLine()) != null) {
            int k = s.indexOf("~~~");
            int i = Integer.parseInt(s.substring(0, k));
            s = s.substring(k + 3);

            k = s.indexOf("~~~");
            int id = Integer.parseInt(s.substring(0, k));
            s = s.substring(k + 3);

            d = Float.parseFloat(s);
            prior.get(i).add(id, d);
            count++;
        }
        buf.close();

        return prior;
    }

    public ArrayList<Double> getPrior(String file, int number_of_domain_plus_out) throws IOException {
        ArrayList<Double> prior = new ArrayList<Double>();
        double total = 0.0;

        for (int i = 0; i < number_of_domain_plus_out; i++) {
            prior.add(0.0);
        }
        BufferedReader buf = new BufferedReader(new FileReader(file));
        String s = "";
        float d = 0.0f;
        while ((s = buf.readLine()) != null) {
            int k = s.indexOf("~~~");
            int i = Integer.parseInt(s.substring(0, k));
            s = s.substring(k + 3);

            k = s.indexOf("~~~");
            int id = Integer.parseInt(s.substring(0, k));
            s = s.substring(k + 3);

            d = Float.parseFloat(s);
            total += d;
            prior.set(i, prior.get(i) + d);
        }
        buf.close();

        for (int i = 0; i < number_of_domain_plus_out; i++) {
            prior.set(i, prior.get(i) / total);
        }
        return prior;
    }

    public double[] loadFILEDouble(String file, int length) throws IOException {
        double[] probs = new double[length];
        BufferedReader buf = new BufferedReader(new FileReader(file));
        String s = "";
        double d = 0.0;
        int count = 0;
        while ((s = buf.readLine()) != null) {
            d = Double.parseDouble(s);
            probs[count] = d;
            count++;
        }
        buf.close();
        return probs;
    }

    public int loadFileSize(String file) throws IOException {
        int filesize = 0;
        BufferedReader buf = new BufferedReader(new FileReader(file));
        String s = "";
        while ((s = buf.readLine()) != null) {
            if (s.trim().length() > 0) {
                filesize++;
            }
        }
        buf.close();
        return filesize;
    }

    
    

    
    public static void main(String[] args) throws IOException, Exception {
        int times = 1;
        int number_of_domains = Integer.parseInt(args[0]);
        int threads = Integer.parseInt(args[1]);
        

        String priorFile = "prior_" + times + "_domains" + number_of_domains;

        SaveModel program = new SaveModel();
        
        int size = program.loadFileSize("small_data/train.en");
        program.runCommand("java -Xmx250g -cp ./UDIT.jar:./trove-3.0.3.jar cat.programs.PLSA "
                        + times + " " + number_of_domains + " " + threads);
        
        System.out.println(program.SMALLEST_VALUE);
        String PATH = System.getProperty("user.dir");
        String corpusFile = PATH + "/small_data/small_hansards.params";

        int maxSentenceSize = Integer.parseInt("65"); // 40
        int numberIterations_model1 = Integer.parseInt("3"); // 5
        String dir = PATH + "/output/saved_alignment_models";
        String modelName = "agreement";
        System.out.println("Saving Models experiment: ");
        System.out.println("Corpus " + corpusFile);
        System.out.println("Size " + size);
        System.out.println("Max Sentence size " + maxSentenceSize);
        System.out.println("Number of iterations " + numberIterations_model1);
        System.out.println("OutputDir " + dir);
        System.out.println("Model Type " + modelName);
        System.out.println("---");

        String baseDir = dir + "/" + modelName + "/" + "small_hansards" + "/" + size;
        String modelDir = baseDir + "/model";
        System.out.println(modelDir);

        ArrayList<ArrayList<Float>> pd1_sents = program.loadFloat(number_of_domains, "ENFRStringpriorwithNorm");

        System.out.println(pd1_sents.size() + " " + pd1_sents.get(0).size());

        ArrayList<Double> priorDomains = program.loadDomainPrior(priorFile);

        for (int iter = 0; iter < numberIterations_model1; iter++) {
            for (int d = 0; d < number_of_domains; d++) {
                //write pd1_sents
                FileWriter pd1sentsFile = new FileWriter("M1pd1sentsFile_" + d);
                for (int j = 0; j < pd1_sents.get(d).size(); j++) {
                    pd1sentsFile.write((pd1_sents.get(d).get(j)) + "\n");
                }
                pd1sentsFile.close();
            }
            final ExecutorService executor = Executors.newFixedThreadPool(threads);
            final List<Callable<Object>> tasks = new ArrayList<Callable<Object>>();

            for (int d = 0; d < number_of_domains; d++) {
                String parameter = "java -Xmx250g -cp trove-3.0.3.jar:UDIT.jar cat.programs.TrainAgreementModel1Separately "
                        + "M1pd1sentsFile_" + d + " " + priorDomains.get(d) + " " + d + " " + iter + " " + size + " " + number_of_domains;
                tasks.add(Executors.callable(new DataProcessorMain(parameter)));
            }

            executor.invokeAll(tasks);
            executor.shutdown();  // not really necessary if the executor goes out of scope.
            System.out.println("Finished all threads");

            ArrayList<Double> expectedPriorDomains = new ArrayList<Double>();
            double totalExpectedPrior = 0.0;
            double iin[][] = new double[number_of_domains][pd1_sents.get(0).size()];
            for (int domain = 0; domain < number_of_domains; domain++) {
                expectedPriorDomains.add(0.0);
                iin[domain] = program.loadFILEDouble("M1temporarilyOutput_" + domain + "_" + iter, pd1_sents.get(0).size());
            }
            FileWriter fi_w = new FileWriter("Output-m1" + iter);

            for (int i = 0; i < pd1_sents.get(0).size(); i++) {
                double total = 0.0;

                for (int domain = 0; domain < number_of_domains; domain++) {
                    total += iin[domain][i];
                }
                float pd1[] = new float[number_of_domains];

                for (int domain = 0; domain < number_of_domains; domain++) {
                    pd1[domain] = (float) (iin[domain][i] / total);
                    /*pd1[domain] = (pd1_sents.get(domain).get(i) * ((float) (iter))
                     +  pd1[domain]) / (float) (iter + 1);//average - trick to avoid potential overfitting ...*/
                    if (pd1[domain] < 0.00001f) {
                        pd1[domain] = 0.00001f;
                    }
                    if (pd1[domain] > 0.99999f) {
                        pd1[domain] = 0.99999f;
                    }

                    pd1_sents.get(domain).set(i, pd1[domain]);
                    expectedPriorDomains.set(domain, expectedPriorDomains.get(domain) + pd1[domain]);
                    totalExpectedPrior += pd1[domain];
                    fi_w.write(domain + "~~~" + i + "~~~" + pd1[domain] + "\n");
                }
            }

            fi_w.close();

            for (int domain = 0; domain < number_of_domains; domain++) {
                priorDomains.set(domain, expectedPriorDomains.get(domain) / totalExpectedPrior);
                if (priorDomains.get(domain) < 0.00001) {
                    priorDomains.set(domain, 0.00001);
                }
            }
        }
        System.out.println("Done loading .... pd1_sents");
        System.out.println(pd1_sents.size() + " " + pd1_sents.get(0).size());
    }

}

class DataProcessorMain implements Runnable {

    String text;

    public DataProcessorMain(String text) {
        this.text = text;
    }

    @Override
    public void run() {
        try {
            //System.out.println("Processing data: " + data);

            runCommand(text);
            //System.out.println(text);
            // Data processing goes here
        } catch (IOException ex) {
            ex.printStackTrace();
            Logger.getLogger(DataProcessorMain.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
            Logger.getLogger(DataProcessorMain.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void runCommand(String command) throws IOException, InterruptedException {
        int count = 0;
        Process p = Runtime.getRuntime().exec(command);

        BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));

        BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));

        // read the output from the command
        String s = "";
        while ((s = stdInput.readLine()) != null) {
            System.out.println(s);
        }
        while ((s = stdError.readLine()) != null) {
            System.out.println(s);
        }
        try {
            int exitVal = p.waitFor();
            System.out.println("Done Controller");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        count++;
    }

}
