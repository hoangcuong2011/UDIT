/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.programs;

/**
 *
 * @author hoangcuong2011
 */

import java.io.FileNotFoundException;
import java.io.IOException;

import cat.common.StaticTools;
import cat.corpus.BilingualCorpus;
import cat.models.AgreementM1;
import cat.models.HMM;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * class to train and save an (HMM) alignment model
 */
public class TrainAgreementModel1Separately {

    double SMALLEST_VALUE = 1E-200;

    public ArrayList<ArrayList<Double>> loadDouble(int number_of_domains, String filename) throws FileNotFoundException, IOException {
        ArrayList<ArrayList<Double>> pd1_sents = new ArrayList<ArrayList<Double>>();
        for (int domain = 0; domain < number_of_domains; domain++) {
            pd1_sents.add(domain, new ArrayList<Double>());
        }
        for (int domain = 0; domain < number_of_domains; domain++) {
            BufferedReader buf = new BufferedReader(new FileReader(filename + "_" + domain));
            String s = "";
            int index = 0;
            while ((s = buf.readLine()) != null) {
                double tmp = Double.parseDouble(s);
                pd1_sents.get(domain).add(index, tmp);
                index++;
            }
            buf.close();
        }
        return pd1_sents;
    }

    public ArrayList<ArrayList<Float>> loadFloat(int number_of_domains, String filename) throws FileNotFoundException, IOException {
        ArrayList<ArrayList<Float>> pd1_sents = new ArrayList<ArrayList<Float>>();
        for (int domain = 0; domain < number_of_domains; domain++) {
            pd1_sents.add(domain, new ArrayList<Float>());
        }
        for (int domain = 0; domain < number_of_domains; domain++) {
            BufferedReader buf = new BufferedReader(new FileReader(filename + "_" + domain));
            String s = "";
            int index = 0;
            while ((s = buf.readLine()) != null) {
                float tmp = Float.parseFloat(s);
                if (tmp < 0.00001f) {
                    tmp = 0.00001f;
                }
                /*if (tmp > 0.99999f) {
                    tmp = 0.99999f;
                }*/                
                pd1_sents.get(domain).add(index, tmp);
                index++;
            }
            buf.close();
        }
        return pd1_sents;
    }

    public ArrayList<ArrayList<Double>> loadStringPrior(String en_or_fr, int total_domains) throws FileNotFoundException, IOException {
        ArrayList<ArrayList<Double>> Stringprior = new ArrayList<ArrayList<Double>>();
        for (int d = 0; d < total_domains; d++) {
            Stringprior.add(new ArrayList<Double>());
            BufferedReader buf = new BufferedReader(new FileReader(en_or_fr + "_" + d + "_" + total_domains));
            String s = "";
            int count = 0;
            while ((s = buf.readLine()) != null) {
                Stringprior.get(d).add(count, Double.parseDouble(s.trim()));
                count++;
            }
            buf.close();
        }
        return Stringprior;

    }

    public ArrayList<Double> loadDomainPrior(String file) throws FileNotFoundException, IOException {
        ArrayList<Double> Stringprior = new ArrayList<Double>();
        BufferedReader buf = new BufferedReader(new FileReader(file));
        String s = "";
        int count = 0;
        while ((s = buf.readLine()) != null) {
            Stringprior.add(count, Double.parseDouble(s.trim()));
            count++;
        }
        buf.close();
        return Stringprior;

    }
    
    public void runCommand(String command) throws IOException, InterruptedException {
        int count = 0;
        Process p = Runtime.getRuntime().exec(command);

        BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));

        BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));

        // read the output from the command
        String s = "";
        while ((s = stdInput.readLine()) != null) {
            System.out.println(s);
        }
        while ((s = stdError.readLine()) != null) {
            System.out.println(s);
        }
        try {
            int exitVal = p.waitFor();
            System.out.println("Done Controller");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        count++;
    }
    
    
    
    public ArrayList<ArrayList<Float>> loadPDSent(String file, int total) throws IOException {
        ArrayList<ArrayList<Float>> prior = new ArrayList<ArrayList<Float>>();
        for (int i = 0; i < total; i++) {
            prior.add(new ArrayList<Float>());
        }
        BufferedReader buf = new BufferedReader(new FileReader(file));
        String s = "";
        float d = 0.0f;
        int count = 0;
        while ((s = buf.readLine()) != null) {
            int k = s.indexOf("~~~");
            int i = Integer.parseInt(s.substring(0, k));
            s = s.substring(k+3);
            
            k = s.indexOf("~~~");
            int id = Integer.parseInt(s.substring(0, k));
            s = s.substring(k+3);
            
            d = Float.parseFloat(s);
            prior.get(i).add(id, d);
            count++;
        }
        buf.close();

        return prior;
    }

    public ArrayList<Double> getPrior(String file, int number_of_domain_plus_out) throws IOException {
        ArrayList<Double> prior = new ArrayList<Double>();
        double total = 0.0;
        
        for (int i = 0; i < number_of_domain_plus_out; i++) {
            prior.add(0.0);
        }
        BufferedReader buf = new BufferedReader(new FileReader(file));
        String s = "";
        float d = 0.0f;
        while ((s = buf.readLine()) != null) {
            int k = s.indexOf("~~~");
            int i = Integer.parseInt(s.substring(0, k));
            s = s.substring(k+3);
            
            k = s.indexOf("~~~");
            int id = Integer.parseInt(s.substring(0, k));
            s = s.substring(k+3);
            
            d = Float.parseFloat(s);
            total+=d;
            prior.set(i, prior.get(i)+d);
        }
        buf.close();
        
        for (int i = 0; i < number_of_domain_plus_out; i++) {
            prior.set(i, prior.get(i)/total);
        }
        return prior;
    }
    
    
    public ArrayList<Float> loadFILE(String file) throws IOException {
        ArrayList<Float> probs = new ArrayList<Float>();
        BufferedReader buf = new BufferedReader(new FileReader(file));
        String s = "";
        float d = 0.0f;
        int count = 0;
        while ((s = buf.readLine()) != null) {
            d = Float.parseFloat(s);
            probs.add(count, d);
            count++;
        }
        buf.close();
        return probs;
    }
    
    public ArrayList<Double> loadStringPriorSpecific(String en_or_fr, int total_domains, int d) throws FileNotFoundException, IOException {
        ArrayList<Double> Stringprior = new ArrayList<Double>();
        BufferedReader buf = new BufferedReader(new FileReader(en_or_fr + "_" + d + "_" + total_domains));
        String s = "";
        int count = 0;
        while ((s = buf.readLine()) != null) {
            Stringprior.add(count, Double.parseDouble(s.trim()));
            count++;
        }
        buf.close();
        return Stringprior;
    }
    
    public static void main(String[] args) throws IOException, Exception {

        String pd1_sents_file = args[0]; //file
        float priorDomains = Float.parseFloat(args[1]); //file
        int domain = Integer.parseInt(args[2]);//domain ID
        int iteration = Integer.parseInt(args[3]);
        int size = Integer.parseInt(args[4]);
        int total_domains = Integer.parseInt(args[5]);
        

        TrainModel1Separately program = new TrainModel1Separately();

        System.out.println(program.SMALLEST_VALUE);
        String PATH = System.getProperty("user.dir");
        String corpusFile = PATH + "/small_data/small_hansards.params";
        //int size = Integer.parseInt("4000100"); // 100k
        int maxSentenceSize = Integer.parseInt("65"); // 40
        int numberIterations_model1 = Integer.parseInt("5"); // 5
        int numberIterations_modelHMM = Integer.parseInt("3"); // 5
        String dir = PATH + "/output/saved_alignment_models";
        String modelName = "agreement";
        System.out.println("Saving Models experiment: ");
        System.out.println("Corpus " + corpusFile);
        System.out.println("Size " + size);
        System.out.println("Max Sentence size " + maxSentenceSize);
        System.out.println("Number of iterations " + numberIterations_model1 + " " + numberIterations_modelHMM);
        System.out.println("OutputDir " + dir);
        System.out.println("Model Type " + modelName);
        System.out.println("---");
        BilingualCorpus corpusF = BilingualCorpus.getCorpusFromFileDescription(
                corpusFile, size, maxSentenceSize);
        BilingualCorpus corpusB = corpusF.reverse();
        String baseDir = dir + "/" + modelName + "/" + corpusF.getName() + "/" + size;
        String modelDir = baseDir + "/model";
        System.out.println(modelDir);

        ArrayList<Double> en_IN_LM
                = program.loadStringPriorSpecific("en.output", total_domains, domain);
        ArrayList<Double> fr_IN_LM
                = program.loadStringPriorSpecific("fr.output", total_domains, domain);
        
        
        ArrayList<Float> pd1_sents = program.loadFILE(pd1_sents_file);
        
        AgreementM1 m1F_pd1;
        //AgreementM1 m1B_pd1;
        int projectonIterations = 5;
        double epsilon = 0.0;

        if(iteration==0) {
            m1F_pd1 = new AgreementM1(corpusF, corpusB, epsilon, projectonIterations, pd1_sents);
            //m1B_pd1 = new AgreementM1(corpusB, corpusF, epsilon, projectonIterations, pd1_sents);
            m1F_pd1.pd = pd1_sents;
            //m1B_pd1.pd = pd1_sents;
        }
        else {
            int abc = iteration-1;
            m1F_pd1 = AgreementM1.loadModel(corpusF, modelDir + "/M1_"+abc+"temporarily_"+"in_" + domain + "/" + "forward");
            //m1B_pd1 = AgreementM1.loadModel(corpusB, modelDir + "/M1_"+"temporarily_"+"in_" + domain + "/" + "backward");
            m1F_pd1.pd = pd1_sents;
            //m1B_pd1.pd = pd1_sents;
        }

        m1F_pd1.train(iteration, numberIterations_model1);
        //m1B_pd1.train(iteration, numberIterations_model1);

        ArrayList<Double> forwardPD1 = new ArrayList<Double>();
        ArrayList<Double> backwardPD1 = new ArrayList<Double>();

        forwardPD1 = m1F_pd1.forward.updatePD1();
        
        backwardPD1 = m1F_pd1.backward.updatePD1();

        FileWriter fi_w = new FileWriter("M1temporarilyOutput_" + domain + "_" + iteration);

        for (int i = 0; i < forwardPD1.size(); i++) {
            double in = 0.0;
            in = forwardPD1.get(i) * en_IN_LM.get(i)
                    + backwardPD1.get(i) * fr_IN_LM.get(i);
            in /= 2.0;
            in *= (double) priorDomains;
            if (in < program.SMALLEST_VALUE) {
                System.out.println(in);
                in = program.SMALLEST_VALUE;
            }
            fi_w.write(in + "\n");
        }

        fi_w.close();
        
        String M1Dir = modelDir + "/M1_" + iteration+"temporarily_" + "in_" + domain + "/";
        StaticTools.createDir(M1Dir);
        m1F_pd1.saveModel(M1Dir + "forward");
        //m1B_pd1.saveModel(M1Dir + "backward");
        
        if(iteration==(numberIterations_model1-1)) {
            //the last time
            M1Dir = modelDir + "/M1_" + 4 + "in_" + domain + "/";
            StaticTools.createDir(M1Dir);
            m1F_pd1.saveModel(M1Dir + "forward");
            //m1B_pd1.saveModel(M1Dir + "backward");
        }
    }
}
