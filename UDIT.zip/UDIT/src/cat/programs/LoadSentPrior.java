/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.programs;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import kylm.model.ngram.NgramLM;
import kylm.model.ngram.reader.ArpaNgramReader;
import kylm.reader.TextStreamSentenceReader;
import kylm.util.KylmConfigUtils;

/**
 *
 * @author hoangcuong2011
 */
public class LoadSentPrior {
    public ArrayList<Double> getStringPrior(String filename, int domain, int iteration, int total_domains,
            String file) throws Exception {
        ArrayList<Double> sentenceProb = new ArrayList<Double>();
        String text = "-arpa " + "abc" + " " + "abc";
        String[] args = text.trim().split(" ");
        final String br = System.getProperty("line.separator");
        KylmConfigUtils config = new KylmConfigUtils(
                "CrossEntropy" + br
                + "A program to find the cross-entropy of one or more language models over a test set" + br
                + "Example: java -cp kylm.jar kylm.main.CrossEntropy -arpa model1.arpa:model2.arpa test.txt");

        // Input format options
        config.addEntry("arpa", KylmConfigUtils.STRING_ARRAY_TYPE, null, false, "models in arpa format (model1.arpa:model2.arpa)");
        config.addEntry("bin", KylmConfigUtils.STRING_ARRAY_TYPE, null, false, "models in binary format (model3.bin:model4.bin)");

        // Debugging options
        config.addEntry("debug", KylmConfigUtils.INT_TYPE, 0, false, "the level of debugging information to print");

        // parse the arguments
        args = config.parseArguments(args);
        int debug = config.getInt("debug");

        // a vector to hold the models
        ArpaNgramReader anr = new ArpaNgramReader();
        String arpa = filename+".ournew_" + domain + "_" + "iteration_" + iteration + "totaldomains_" + total_domains;
        NgramLM next = anr.read(arpa);
        if (next.getName() == null) {
            next.setName(arpa);
        }

        if (1 == 1) {
            // get the input stream to load the input
            InputStream is = (args.length == 0 ? System.in : new FileInputStream(file));
            TextStreamSentenceReader tssl = new TextStreamSentenceReader(is);
// calculate the entropies
            int sentenceCount = 0;
            for (String[] sent : tssl) {
                String tmp1 = "";
                String tmp2 = "";
                for (int i = 0; i < sent.length; i++) {
                    tmp1 += sent[i] + " ";
                }
                for (int i = sent.length - 1; i >= 0; i--) {
                    tmp2 += sent[i] + " ";
                }
                tmp1 += "";
                tmp2 += "";
                tmp1 = tmp1.trim();
                tmp2 = tmp2.trim();
                String[] sent1 = tmp1.split(" ");
                String[] sent2 = tmp2.split(" ");
                double temp = Math.pow(10, next.getSentenceProb(sent1));
                sentenceProb.add(sentenceCount, Math.pow(10, next.getSentenceProb(sent1)));
                
                sentenceCount++;
            }

            FileWriter fi_w = new FileWriter(filename+ "_" + domain + "_" + total_domains);
            for (int i = 0; i < sentenceProb.size(); i++) {
                fi_w.write(sentenceProb.get(i) + "\n");
            }
            fi_w.close();

            
        }
        
        return sentenceProb;
    }
    
    public static void main (String args[]) throws Exception {
        
        LoadSentPrior program = new LoadSentPrior();
        
        
        String filename = args[0];
        int domain = Integer.parseInt(args[1]);
        int iteration = Integer.parseInt(args[2]);
        int total_domains = Integer.parseInt(args[3]);
        String file = args[4];
        program.getStringPrior(filename, domain, iteration, total_domains, file);
    }
}
