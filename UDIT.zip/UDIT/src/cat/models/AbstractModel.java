package cat.models;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


import cat.alignmnets.Alignment;
import cat.alignmnets.AlignmentEvaluator;
import cat.alignmnets.AlignmentsSet;
import cat.alignmnets.AlignmentEvaluator.Evaluation;
import cat.corpus.BilingualCorpus;
import cat.models.stats.EStepStats;

/**
 * Abstract class that defines common methods for all word alignments algorithms
 * 
 * @author javg
 * 
 */
public abstract class AbstractModel {

    public BilingualCorpus _corpus;
    public int _nSentences;
    public int _sourceSize, _foreignSize;
    public int _numericUnderFlow = 0;
    public int _trainingIterations;
    // Indicates if the model is already train or not. Decoding is only possible
    // on a trained model
    public boolean _trained = false;
    public int domain = -1;

    public AbstractModel() {
    }

    public BilingualCorpus getCorpus() {
        return _corpus;
    }

    public void setCorpus(BilingualCorpus corpus) {
        _corpus = corpus;
    }

    public AbstractModel(BilingualCorpus corpus) {
        System.out.println("Started the Initialization of " + getName());
        _corpus = corpus;
        _sourceSize = corpus.getSourceSize();
        _foreignSize = corpus.getForeignSize();
        _nSentences = corpus.getNumberOfTrainingSentences();
        System.out.println("Ended the Initialization of " + getName());
    }
    
    

    /** 
     * Saves the model to a given directory
     * Must save
     * - Description of the corpus used
     * - Information regarding the model
     * 	 - Iterations trained
     *   - Any model parameters
     *   - Different model parameters
     * - Time stamp
     * @param directory
     */
    public void saveModel(String directory) {
        if (!trained()) {
            System.out.println(getName() + ": Model not trained. Cannot save model");
            //System.exit(-1);
        }
        //Save corpus
        _corpus.saveDescription(directory);
        try {
            PrintStream file = new PrintStream(new FileOutputStream(directory + "stamp"));
            printStamp(file);
        } catch (FileNotFoundException e) {
            System.out.println(getName() + ": Could not save model");
            System.exit(-1);
        }
    }

    public void printStamp(PrintStream file) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        java.util.Date date = new Date();
        System.out.println("Current Date Time : " + dateFormat.format(date));
    }

    // Return the likelihood of the corpus
    public abstract EStepStats eStep();

    public boolean trained() {
        return _trained;
    }

    public void setTrained() {
        _trained = true;
    }

    public abstract void mStep();

    public abstract String getName();

    // Normal EM training
    public void train(int currentIter, int iterations) {
        if (1 != 0) {
            _trainingIterations = iterations;
            System.out.println("Starting " + getName() + " Training");
            initializeTrain();
        }
        EStepStats d = new EStepStats(), old = new EStepStats();
        // /DEBUG CODE
        System.out.println("Iteration " + (currentIter + 1));
        System.out.flush();
        // E-Step
        System.out.println(" e Step");
        d.startTime();
        d.add(eStep());
        d.stopTime();
        System.out.println(d.makeVerbose(old));
        // M-Step
        old = d;
        d = new EStepStats();
        mStep();
        System.out.println("m Step");
        System.out.flush();

        if (currentIter == iterations - 1) {
            setTrained();
            finalizeTrain();
            System.out.println();
        }
    }

    public Evaluation[] trainWithResults(int iterations, byte sentenceSource) {
        Evaluation[] evals = new Evaluation[iterations];
        System.out.println("Starting " + getName() + " Training");
        initializeTrain();
        EStepStats d = new EStepStats(), old = new EStepStats();
        for (int k = 0; k < iterations; k++) {
            System.out.println("Iteration " + (k + 1));
            System.out.flush();
            // E-Step
            System.out.println(" e Step");
            d.startTime();
            d.add(eStep());
            d.stopTime();
            System.out.println(d.makeVerbose(old));
            // M-Step
            old = d;
            d = new EStepStats();
            mStep();
            System.out.println("m Step");
            System.out.flush();
            AlignmentsSet predicted = viterbiAlignments(sentenceSource);
            evals[k] = AlignmentEvaluator.evaluate(predicted, _corpus.getAlignments(sentenceSource));
        }
        setTrained();
        finalizeTrain();
        System.out.println();
        return evals;
    }

    public abstract void initializeTrain();

    public abstract void finalizeTrain();

    /**
     * Gets the posterior probability of a given phrase
     * @param sentenceNumber
     * @param sentenceSource
     * @param foreingSentence
     * @param sourceSentence
     * @param startSourceIndex
     * @param endSourceIndex
     * @param startForeignIndex
     * @param endForeignIndex
     * @return
     */
    public abstract double getPhrasePosterior(int sentenceNumber,
            byte sentenceSource, int[] foreingSentence, int[] sourceSentence,
            int startSourceIndex, int endSourceIndex, int startForeignIndex,
            int endForeignIndex);

    /**
     * Gets the posterior probability of a given null phrase
     * @param sentenceNumber
     * @param sentenceSource
     * @param foreingSentence
     * @param sourceSentence
     * @param startForeignIndex
     * @param endForeignIndex
     * @return
     */
    public abstract double getNullPhrasePosterior(int sentenceNumber,
            byte sentenceSource, int[] foreingSentence, int[] sourceSentence,
            int startForeignIndex, int endForeignIndex);

    /////////////////////////////////////////////////////////////////
    // DECODING CODE
    /////////////////////////////////////////////////////////////////
    /** return the alignments of the selected in sample from the training corpus */
    public AlignmentsSet viterbiAlignments(int[] sample, byte sentenceSource) {
        assert _trained;
        AlignmentsSet set = new AlignmentsSet();
        for (int i = 0; i < sample.length; i++) {
            set.addAlignment(viterbiAlignment(sample[i], sentenceSource));
        }
        return set;
    }

    /** return the alignments of the selected in sample from the training corpus */
    public AlignmentsSet posteriorAlignments(int[] sample, byte sentenceSource,
            float treshold) {
        assert _trained;
        AlignmentsSet set = new AlignmentsSet();
        for (int i = 0; i < sample.length; i++) {
            set.addAlignment(posteriorDecodingAlignment(sample[i],
                    sentenceSource, treshold));
        }
        return set;
    }

    public AlignmentsSet viterbiAlignments(byte sentenceSource,
            boolean printPosteriors, PrintStream out) {
        assert _trained;
        AlignmentsSet set = new AlignmentsSet();
        // System.out.println(_corpus.getNumSentences(sentenceSource));
        for (int i = 0; i < _corpus.getNumSentences(sentenceSource); i++) {
            set.addAlignment(viterbiAlignment(i, sentenceSource));
        }
        return set;
    }

    public AlignmentsSet viterbiAlignments(byte sentenceSource) {
        return viterbiAlignments(sentenceSource, false, null);
    }

    public AlignmentsSet posteriorAlignments(byte sentenceSource, float treshold) {
        assert _trained;
        AlignmentsSet set = new AlignmentsSet();
        for (int i = 0; i < _corpus.getNumSentences(sentenceSource); i++) {
            set.addAlignment(posteriorDecodingAlignment(i, sentenceSource,
                    treshold));
        }
        return set;
    }

    public abstract Alignment viterbiAlignment(int sentenceNumber,
            byte sentenceSource);

    public abstract Alignment posteriorDecodingAlignment(int sentenceNumber,
            byte sentenceSource, float treshhold);

    /////////////////////////////////////////////////////////////////
    // POSTERIOR TUNNING CODE
    /////////////////////////////////////////////////////////////////
    public float tuneTreshholdAER(byte sentenceSource) {
        int[] sentences = new int[_corpus.getNumSentences(sentenceSource)];
        for (int i = 0; i < sentences.length; i++) {
            sentences[i] = i;
        }
        return tuneTresholdAERAux(sentences, sentenceSource);
    }

    public float tuneTreshholdF1(byte sentenceSource, float alpha) {
        int[] sentences = new int[_corpus.getNumSentences(sentenceSource)];
        for (int i = 0; i < sentences.length; i++) {
            sentences[i] = i;
        }
        return tuneTreshholdBalancedF1Aux(sentences, sentenceSource, alpha);
    }

    public float tuneTresholdAERAux(int[] sentences, byte sentenceSource) {
        System.out.print("\t\tTunning T: ");
        System.out.flush();
        float treshhold = 0f;
        int divisions = 100;
        float aer = 1;
        for (int i = 1; i <= divisions; i++) {
            // System.out.println(i);
            AlignmentsSet predicted = posteriorAlignments(sentences,
                    sentenceSource, 1f * i / divisions);
            float[] results = AlignmentEvaluator.calculateMeasures(predicted,
                    _corpus.getAlignments(sentences, sentenceSource));
            // System.out.println(" " + results[2] + " "+ (1f*i/divisions) );
            if (results[2] < aer) {
                aer = results[2];
                treshhold = 1f * i / divisions;
            }
            // System.out.println(treshhold+", "+aer);
        }
        System.out.println(treshhold + ", " + aer);
        return treshhold;
    }

    public float tuneTreshholdBalancedF1Aux(int[] sentences,
            byte sentenceSource, float alpha) {
        System.out.print("\t\tTunning T: ");
        System.out.flush();
        float treshhold = 0f;
        int divisions = 100;
        float current = 0;
        float precisionS = 0;
        float recallS = 0;
        for (int i = 1; i <= divisions; i++) {
            // System.out.println(i);
            AlignmentsSet predicted = posteriorAlignments(sentences,
                    sentenceSource, 1f * i / divisions);
            float[] results = AlignmentEvaluator.calculateMeasures(predicted,
                    _corpus.getAlignments(sentences, sentenceSource));
            // System.out.println(" " + results[2] + " "+ (1f*i/divisions) );
            float precision = results[0];
            float recall = results[1];
            float f1 = 1 / (alpha / precision + (1 - alpha) / recall);
            if (f1 > current) {
                current = f1;
                precisionS = precision;
                recallS = recall;
                treshhold = 1f * i / divisions;
            }
        }
        System.out.println(treshhold + ", " + current + "Precision "
                + precisionS + " Recall " + recallS);
        return treshhold;
    }

    public float tuneTreshholdPrecisionRecall(byte sentenceSource,
            boolean precision) {
        System.out.print("\t\tTunning T: ");
        System.out.flush();
        float treshhold = 0f;
        int divisions = 100;
        float current = 0;
        for (int i = 1; i <= divisions; i++) {
            // System.out.println(i);
            AlignmentsSet predicted = posteriorAlignments(sentenceSource, 1f
                    * i / divisions);
            float[] results = AlignmentEvaluator.calculateMeasures(predicted,
                    _corpus.getAlignments(sentenceSource));
            // System.out.println(" " + results[2] + " "+ (1f*i/divisions) );
            if (precision) {
                if (results[0] > current) {
                    current = results[0];
                    treshhold = 1f * i / divisions;
                }
            } else {
                if (results[1] > current) {
                    current = results[1];
                    treshhold = 1f * i / divisions;
                }
            }
            // System.out.println(treshhold+", "+"Precision" + results[0]+
            // "Recall " + results[1] );
        }
        System.out.println(treshhold + ", " + current);
        return treshhold;
    }

    /**
     * tune threshold to get expected number of alignments on given sample of
     * training data. implemented as binary search.
     */
    public float tuneThresholdNumPoints(int numPts, int[] sample,
            byte sentenceSource) {
        System.out.print("\t\tTunning T for " + numPts + " points : ");
        System.out.flush();
        float min = 0f;
        int numMin = posteriorAlignments(sample, sentenceSource, min).numberOfAlignedPoints();
        float max = 1f;
        int numMax = posteriorAlignments(sample, sentenceSource, max).numberOfAlignedPoints();
        // 10 binary steps means difference of < 10^-3
        for (int i = 1; i <= 10; i++) {
            float mid = (min + max) / 2;
            int numMid = posteriorAlignments(sample, sentenceSource, mid).numberOfAlignedPoints();
            if (numMid < numPts) {
                max = mid;
                numMax = numMid;
            } else {
                min = mid;
                numMin = numMid;
            }
        }
        System.out.println(min + max / 2 + " " + numMin + " " + numMax);
        return min + max / 2;
    }

    // Fix a specic precision or recall
    public float tuneTreshholdPrecisionRecallFixOtherValue(byte sentenceSource,
            boolean precision, float fixValue, float fixError) {
        System.out.print("\t\tTunning T: ");
        System.out.flush();
        float treshhold = 0f;
        int divisions = 100;
        float current = 0, other = 0;
        for (int i = 1; i <= divisions; i++) {
            // System.out.println(i);
            AlignmentsSet predicted = posteriorAlignments(sentenceSource, 1f
                    * i / divisions);
            float[] results = AlignmentEvaluator.calculateMeasures(predicted,
                    _corpus.getAlignments(sentenceSource));
            // System.out.println(" " + results[2] + " "+ (1f*i/divisions) );
            if (precision) {
                if ((results[0] > current)
                        && Math.abs((results[1] - fixValue)) < fixError) {
                    current = results[0];
                    other = results[1];
                    treshhold = 1f * i / divisions;
                }
            } else {
                if ((results[1] > current)
                        && Math.abs((results[0] - fixValue)) < fixError) {
                    current = results[1];
                    other = results[1];
                    treshhold = 1f * i / divisions;
                }
            }
            // System.out.println(treshhold+", "+"Precision" + results[0]+
            // "Recall " + results[1] );
        }
        if (precision) {
            System.out.println(treshhold + ", Precision " + current
                    + "  Recall " + other);
        } else {
            System.out.println(treshhold + ", Recall " + current
                    + " Precision " + other);
        }
        return treshhold;
    }
}
