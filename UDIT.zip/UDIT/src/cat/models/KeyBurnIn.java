
/*
 * Hoang Cuong
 * ILLC, UvA
 */


package cat.models;

import java.util.ArrayList;

/**
 *
 * @author hoangcuong2011
 */
class KeyBurnIn {

    private final int en;
    private final int fr;
    private int Code = 0;

    public int getEn() {
        return en;
    }

    public int getFr() {
        return fr;
    }

    public int get_Code() {
        return Code;
    }

    KeyBurnIn(final int en, final int fr) {
        this.en = en;
        this.fr = fr;
    }

    KeyBurnIn(final int en, final int fr, final int hashCode) {
        this.en = en;
        this.fr = fr;
        this.Code = hashCode;

    }
    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof KeyBurnIn) {
            KeyBurnIn test = (KeyBurnIn) obj;
            if (Code != obj.hashCode()) {
                return false;
            }
            if (en != test.en) {
                //System.out.println("Error\t"+en+"\t"+vi+"\t"+test.en+"\t"+test.vi+"\t"+hashCode);
                return false;
            }
            if (fr != test.fr) {
                //System.out.println("Error\t"+en+"\t"+vi+"\t"+test.en+"\t"+test.vi+"\t"+hashCode);
                return false;
            }
            return true;
        }
        return false;
    }

    int CantorPair(int x, int y) {
        if (x >= y) {
            return x * x + x + y;
        } else {
            return y * y + x;
        }
    }

    @Override
    public int hashCode() {
        if (get_Code() == 0) {
            Code = CantorPair(en, fr);
        }
        return get_Code();
    }
}
