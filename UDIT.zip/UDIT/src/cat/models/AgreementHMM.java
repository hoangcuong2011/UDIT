package cat.models;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;

import cat.alignmnets.Alignment;
import cat.alignmnets.AlignmentEvaluator;
import cat.alignmnets.AlignmentsSet;
import cat.alignmnets.AlignmentEvaluator.Evaluation;
import cat.common.StaticTools;
import cat.corpus.BilingualCorpus;
import cat.models.stats.AgreeEStepStats;
import cat.models.stats.ProjectionStats;
import java.util.ArrayList;

public class AgreementHMM extends AbstractModel {

    public HMM forward;
    public HMM backward;
    double epsilon;
    int _projectionIterations;
    boolean _trained = false;
    public ArrayList<Float> pd = null;

    public AgreementHMM(BilingualCorpus forwardCorpus,
            BilingualCorpus backwardCorpus, double epsilon, int projectionIterations, ArrayList<Float> pd) throws IOException {
        this(forwardCorpus, backwardCorpus, null, null, epsilon, projectionIterations, pd);
    }

    public AgreementHMM(BilingualCorpus forwardCorpus,
            BilingualCorpus backwardCorpus, double epsilon, double smooth, int projectionIterations, ArrayList<Float> pd) throws IOException {
        this(forwardCorpus, backwardCorpus, null, null, epsilon, smooth, projectionIterations, pd);
    }

    public AgreementHMM(BilingualCorpus forwardCorpus,
            BilingualCorpus backwardCorpus, SparseTranslationTable forwardT,
            SparseTranslationTable backwardT, double epsilon, int projectionIterations, ArrayList<Float> pd) throws IOException {
        this(forwardCorpus, backwardCorpus, forwardT, backwardT, epsilon, 0, projectionIterations, pd);
    }

    public AgreementHMM(BilingualCorpus forwardCorpus,
            BilingualCorpus backwardCorpus, SparseTranslationTable forwardT,
            SparseTranslationTable backwardT, double epsilon, double smooth, int projectionIterations, ArrayList<Float> pd) throws IOException {
        this.epsilon = epsilon;
        this._projectionIterations = projectionIterations;
        this._corpus = forwardCorpus;
        System.out.println("Init Agreement HMM with epsilon " + epsilon + " smooth " + smooth + " projectionIterations " + projectionIterations);
        if (forwardT == null) {
            forward = new HMM(forwardCorpus, smooth);
        } else {
            forward = new HMM(forwardCorpus, forwardT, smooth);
        }
        forward.pd = pd;
        if (backwardT == null) {
            backward = new HMM(backwardCorpus, smooth);
        } else {
            backward = new HMM(backwardCorpus, backwardT, smooth);
        }
        backward.pd = pd;
    }

    AgreementHMM() {
    }

    
    // /////////////////SAVE AND LOAD MODELS
    public void saveModel(String directory) {
        forward.saveModel(directory + "forward");
        backward.saveModel(directory + "backward");
        try {
            PrintStream file = new PrintStream(new FileOutputStream(directory + "epsilon"));
            file.println(_projectionIterations);
            file.println(epsilon);
        } catch (FileNotFoundException e) {
            System.out.println(getName() + ": Could not save model");
            System.exit(-1);
        }
    }

    public static AgreementHMM loadModel(BilingualCorpus forwardCorpus,
            BilingualCorpus backwardCorpus, String directory) {
        AgreementHMM model = new AgreementHMM();
        try {
            BufferedReader file = new BufferedReader(new FileReader(directory
                    + "epsilon"));
            model._projectionIterations = Integer.parseInt(file.readLine());
            model.epsilon = Double.parseDouble(file.readLine());
            System.out.println("Reading Forward: " + directory + "forward");
            model.forward = HMM.loadModel(forwardCorpus, directory + "forward");
            model._corpus = forwardCorpus;
            System.out.println("Reading Forward: " + directory + "backward");
            model.backward = HMM.loadModel(backwardCorpus, directory
                    + "backward");
        } catch (FileNotFoundException e) {
            System.out.println(model.forward.getName() + " Could not read model file not found "
                    + e.toString());
            System.exit(-1);
        } catch (NumberFormatException e) {
            System.out.println(model.forward.getName() + "Could not read model number conversion exception"
                    + e.toString());
            System.exit(-1);

        } catch (IOException e) {
            System.out.println(model.forward.getName() + ": Could not read model"
                    + e.toString());
            System.exit(-1);
        }
        return model;
    }

    AgreementHMM(HMM forward, HMM backward) {
        this.forward = forward;
        this.backward = backward;
        this._corpus = forward._corpus;
    }

    public AgreementHMM getBackwardModel() {
        AgreementHMM res = new AgreementHMM(backward, forward);
        res._trained = _trained;
        return res;
    }

    public String getName() {
        return "Agremement HMM";
    }

    public void setTrained() {
        _trained = true;
        forward.setTrained();
        backward.setTrained();
    }

    public void initializeTrain() {
        forward.initializeTrain();
        backward.initializeTrain();
    }

    public void finalizeTrain() {
        forward.finalizeTrain();
        backward.finalizeTrain();
    }

    public double getNullPhrasePosterior(int phraseNumber, byte phraseSource,
            int[] foreingSentence, int[] sourceSentence, int startForeignIndex,
            int endForeignIndex) {
        return forward.getNullPhrasePosterior(phraseNumber, phraseSource,
                foreingSentence, sourceSentence, startForeignIndex,
                endForeignIndex);
    }

    public double getPhrasePosterior(int phraseNumber, byte phraseSource,
            int[] foreingSentence, int[] sourceSentence, int startSourceIndex,
            int endSourceIndex, int startForeignIndex, int endForeignIndex) {
        return forward.getPhrasePosterior(phraseNumber, phraseSource,
                foreingSentence, sourceSentence, startSourceIndex,
                endSourceIndex, startForeignIndex, endForeignIndex);
    }

    public ProjectionStats projectPosteriors(double[][][] probCache,
            double[][][] forwardTables, double[][][] backwardTables,
            double[][][] posteriors, int sSize, int fSize, int sentenceNumber) {

        ProjectionStats stats = new ProjectionStats(_projectionIterations);
        double posteriorsF[][] = posteriors[0];
        double posteriorsB[][] = posteriors[1];
        double[][] originalPosteriorsF = StaticTools.copyMatrix(posteriorsF, fSize, sSize * 2);
        double[][] originalPosteriorsB = StaticTools.copyMatrix(posteriorsB, sSize, fSize * 2);
        double probCacheF[][] = probCache[0];
        double probCacheB[][] = probCache[1];
        double forwardF[][] = forwardTables[0];
        double forwardB[][] = forwardTables[1];
        double backwardF[][] = backwardTables[0];
        double backwardB[][] = backwardTables[1];

        //double[][] probCacheFP = probCacheF.clone();
        //double[][] probCacheBP = probCacheB.clone();

        double[][] probCacheFP = StaticTools.copyMatrix(probCacheF, fSize, sSize * 2);
        double[][] probCacheBP = StaticTools.copyMatrix(probCacheB, sSize, fSize * 2);

        double[][] phi = new double[fSize][sSize];
        for (int grI = 0; grI < _projectionIterations; grI++) {
            double lRate = 10.0 / (10.0 + grI);
            double totalViolation = 0;
            for (int fi = 0; fi < fSize; fi++) {
                for (int si = 0; si < sSize; si++) {
                    // Update phi and lambda
                    double ePsi = posteriorsF[fi][si] - posteriorsB[si][fi];
                    double phiUpdate = lRate * (-ePsi);
                    totalViolation += Math.abs(-ePsi);
                    double newPhi = phiUpdate + phi[fi][si];
                    probCacheF[fi][si] = probCacheFP[fi][si] * Math.exp(newPhi);
                    probCacheB[si][fi] = probCacheBP[si][fi] * Math.exp(-newPhi);
                    phi[fi][si] = newPhi;
                }
            }
            // Renormalizing
            forwardF = forward.makeForward(sSize, fSize, probCacheF);
            backwardF = forward.makeBackward(sSize, fSize, probCacheF);
            double likelihoodF = forward.makeLikelihood(forwardF[0],
                    backwardF[0]);
            posteriorsF = forward.makePosterior(forwardF, backwardF,
                    likelihoodF);


            forwardB = backward.makeForward(fSize, sSize, probCacheB);
            backwardB = backward.makeBackward(fSize, sSize, probCacheB);
            double likelihoodB = backward.makeLikelihood(forwardB[0],
                    backwardB[0]);
            posteriorsB = backward.makePosterior(forwardB, backwardB,
                    likelihoodB);


            //if (postStats) {			
            stats.addViolation(totalViolation, grI);
            //System.out.println("   "+sentenceNumber+"  final violation = "+totalViolation);	

            // Calculate thw KL(q|p) which is what we are minimizing
            stats.addForwardKL(cat.common.StaticTools.KLDistance(posteriorsF, originalPosteriorsF, fSize, sSize * 2), grI);
            stats.addBackwardKL(cat.common.StaticTools.KLDistance(posteriorsB, originalPosteriorsB, sSize, fSize * 2), grI);
            //}

        }
        posteriors[0] = posteriorsF;
        posteriors[1] = posteriorsB;
        forwardTables[0] = forwardF;
        forwardTables[1] = forwardB;
        backwardTables[0] = backwardF;
        backwardTables[1] = backwardB;
        probCache[0] = probCacheF;
        probCache[1] = probCacheB;
        return stats;
    }

//	 Its here just because of the stats. Should be removed.
    public void train(int currentIter, int iterations) {
        if (1 != 0) {
            _trainingIterations = iterations;
            System.out.println("Starting " + getName() + " Training");
            initializeTrain();
        }
        AgreeEStepStats d = new AgreeEStepStats(), old = new AgreeEStepStats();
        // /DEBUG CODE
        System.out.println("Iteration " + (currentIter + 1));
        System.out.flush();
        // E-Step
        System.out.println(" e Step");
        d.startTime();
        d.add(eStep());

        d.stopTime();
        System.out.println(d.makeVerbose(old));
        // M-Step
        old = d;
        d = new AgreeEStepStats();
        mStep();
        System.out.println("m Step");
        System.out.flush();

        if (currentIter == iterations - 1) {
            setTrained();
            finalizeTrain();
            System.out.println();
        }
    }

    public ArrayList<Double> updatePD1forward() {
//        This is an immediate step
        ArrayList<Double> arrList = new ArrayList<Double>();


        //forward.clearCounts();
        for (int i = 0; i < forward._nSentences; i++) {
            int[] s = forward._corpus.getSourceSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int sSize = s.length;
            int[] f = forward._corpus.getForeignSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int fSize = f.length;


            // indexed by[fi][si] sSize..2*sSize corresponds to null word
            // probability
            double[][] probCacheF = forward.makeProbCache(f, s);
            double[][] forwardF = forward.makeForward(sSize, fSize, probCacheF);
            double[][] backwardF = forward.makeBackward(sSize, fSize,
                    probCacheF);
            double likelihoodF = forward.makeLikelihood(forwardF[0], backwardF[0]);

            arrList.add(likelihoodF);
        }
        return arrList;
    }

   
    
    /**
     * Hoang Cuong - slight modification
     */
    
    
    public ArrayList<Double> updatePD1() {    
        ArrayList<Double> arrList = new ArrayList<Double>();

        //forward.clearCounts();
        for (int i = 0; i < forward._nSentences; i++) {
            int[] s = forward._corpus.getSourceSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int sSize = s.length;
            int[] f = forward._corpus.getForeignSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int fSize = f.length;

            // indexed by[fi][si] sSize..2*sSize corresponds to null word
            // probability
            double[][] probCacheF = forward.makeProbCache(f, s);
            double[][] forwardF = forward.makeForward(sSize, fSize, probCacheF);
            double[][] backwardF = forward.makeBackward(sSize, fSize,
                    probCacheF);
            double likelihoodF = forward.makeLikelihood(forwardF[0], backwardF[0]);

            arrList.add(likelihoodF);
        }

        return arrList;
    }

    public ArrayList<Double> updatePD1backward() {
//        This is an immediate step
        ArrayList<Double> arrList = new ArrayList<Double>();
        //backward.clearCounts();
        for (int i = 0; i < forward._nSentences; i++) {
            int[] s = forward._corpus.getSourceSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int sSize = s.length;
            int[] f = forward._corpus.getForeignSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int fSize = f.length;

            // indexed by[si][fi] sSize..2*sSize corresponds to null word
            // probability
            double[][] probCacheB = backward.makeProbCache(s, f);
            double[][] forwardB = backward.makeForward(fSize, sSize, probCacheB);
            double[][] backwardB = backward.makeBackward(fSize, sSize,
                    probCacheB);
            double likelihoodB = backward.makeLikelihood(forwardB[0],
                    backwardB[0]);
            arrList.add(likelihoodB);
        }
        return arrList;
    }

    public AgreeEStepStats eStep(/*boolean postStats*/) {
        double totalLikelihoodF = 0;
        double totalLikelihoodB = 0;
        ProjectionStats totalPStats = new ProjectionStats(_projectionIterations);
        forward.clearCounts();
        backward.clearCounts();
        for (int i = 0; i < forward._nSentences; i++) {
            int[] s = forward._corpus.getSourceSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int sSize = s.length;
            int[] f = forward._corpus.getForeignSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int fSize = f.length;


            // indexed by[fi][si] sSize..2*sSize corresponds to null word
            // probability
            double[][] probCacheF = forward.makeProbCache(f, s);
            double[][] forwardF = forward.makeForward(sSize, fSize, probCacheF);
            double[][] backwardF = forward.makeBackward(sSize, fSize,
                    probCacheF);
            double likelihoodF = forward.makeLikelihood(forwardF[0],
                    backwardF[0]);

            // indexed by[si][fi] sSize..2*sSize corresponds to null word
            // probability
            double[][] probCacheB = backward.makeProbCache(s, f);
            double[][] forwardB = backward.makeForward(fSize, sSize, probCacheB);
            double[][] backwardB = backward.makeBackward(fSize, sSize,
                    probCacheB);
            double likelihoodB = backward.makeLikelihood(forwardB[0],
                    backwardB[0]);

            assert forwardB.length == sSize;
            assert backwardB.length == sSize;
            double[][] posteriorsF = forward.makePosterior(forwardF, backwardF,
                    likelihoodF);
            double[][] posteriorsB = backward.makePosterior(forwardB,
                    backwardB, likelihoodB);
            
//			 check for underflow
            if (likelihoodF <= 1.0e-200 || likelihoodB <= 1.0e-200) {
                _numericUnderFlow++;
                continue;
            }
            double[][][] probCache = {probCacheF, probCacheB};
            double[][][] forwardTables = {forwardF, forwardB};
            double[][][] backwardTables = {backwardF, backwardB};
            double[][][] posteriors = {posteriorsF, posteriorsB};

            ProjectionStats stats = projectPosteriors(probCache, forwardTables, backwardTables, posteriors, sSize, fSize, i);
            totalPStats.add(stats);

            probCacheF = probCache[0];
            probCacheB = probCache[1];
            forwardF = forwardTables[0];
            forwardB = forwardTables[1];
            backwardF = backwardTables[0];
            backwardB = backwardTables[1];
            posteriorsF = posteriors[0];
            posteriorsB = posteriors[1];

            likelihoodF = forward.makeLikelihood(forwardF[0], backwardF[0]);
            likelihoodB = backward.makeLikelihood(forwardB[0], backwardB[0]);
            totalLikelihoodF += Math.log(likelihoodF);
            totalLikelihoodB += Math.log(likelihoodB);

            forward.addToCounts(pd.get(i), s, f, posteriorsF);
            backward.addToCounts(pd.get(i), f, s, posteriorsB);

            forward.addToTransitions(pd.get(i), probCacheF, forwardF, backwardF,
                    likelihoodF);
            backward.addToTransitions(pd.get(i), probCacheB, forwardB, backwardB,
                    likelihoodB);
        }
        AgreeEStepStats d = new AgreeEStepStats();
        d.logLikelihoodF = totalLikelihoodF;
        d.logLikelihoodB = totalLikelihoodB;
        d.numSents = forward._corpus.getNumberOfTrainingSentences();
        d.pStats = totalPStats;
        return d;
    }

    public void mStep() {
        forward.mStep();
        backward.mStep();
    }

    public Alignment posteriorDecodingAlignment(int sentenceNumber,
            byte sentenceSource, float treshhold) {
        return forward.posteriorDecodingAlignment(sentenceNumber,
                sentenceSource, treshhold);
    }

    public Alignment viterbiAlignment(int sentenceNumber, byte sentenceSource) {
        return forward.viterbiAlignment(sentenceNumber, sentenceSource);
    }    
}
