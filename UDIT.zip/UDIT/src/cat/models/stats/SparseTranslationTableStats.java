package cat.models.stats;

import java.io.IOException;

import cat.corpus.BilingualCorpus;
import cat.models.SparseTranslationTable;

public class SparseTranslationTableStats {

	public double meanEntropy(BilingualCorpus corpus, SparseTranslationTable tt) {
		double entropy = 0;
		for (int id = 0; id < corpus.getSourceSize(); id++) {
			entropy += entropy(id, tt);
		}
		return entropy / corpus.getSourceSize();
	}

	// Return the entropy by buckets of number of occurunces of source word
	public double[] entropyByCounts(BilingualCorpus corpus,
			SparseTranslationTable tt) {

		// Mean entropy by buckets
		// 0 -- c < 5 count
		// 5 -- 10 < c < 10
		// 10 -- > 30
		// > 30
		double entropy[] = new double[4];
		int counts[] = new int[4];
		System.out.println("Starting anaylising entroy");
		for (int id = 0; id < corpus.getSourceSize(); id++) {
			int scounts = corpus.getSourceWordCounts(id);
			if (scounts <= 5) {
				entropy[0] += entropy(id, tt);
				counts[0]++;
			} else if (scounts <= 10) {
				entropy[1] += entropy(id, tt);
				counts[1]++;
			} else if (scounts <= 30) {
				entropy[2] += entropy(id, tt);
				counts[2]++;
			} else {
				entropy[3] += entropy(id, tt);
				counts[3]++;
			}

		}
		for (int i = 0; i < entropy.length; i++) {
			entropy[i] = entropy[i] / counts[i];
		}
		System.out.println("Ended anaylising entroy");
		return entropy;
	}

	public double entropy(int sourceId, SparseTranslationTable tt) {
		// System.out.print(sourceId + " ");
		double entropy = 0;
		// Gets all entries for T(f|sourceId)
		double[] probs = tt.getProbabilitiesForSource(sourceId);
		for (int i = 0; i < probs.length; i++) {
			// TODO should be log2
			// System.out.println(probs[i] + Math.log(i)/Math.log(2));
			double prob = probs[i];
			if (prob != 0) {
				entropy += probs[i] * Math.log(probs[i] / Math.log(2));
			}
		}
		entropy *= -1;
		// System.out.println(sourceId + " " + entropy);
		return entropy;
	}

	public static void main(String[] args) throws IOException {
		SparseTranslationTableStats stats = new SparseTranslationTableStats();
		BilingualCorpus corpus = BilingualCorpus.getCorpusFromFileDescription(
				args[0], Integer.MAX_VALUE);
		SparseTranslationTable table = SparseTranslationTable
				.LoadTranslationTable(corpus, args[1]);

		double[] counts = stats.entropyByCounts(corpus, table);
		System.out.println("Entropy counts < 5 " + counts[0]);
		System.out.println("Entropy counts < 10 " + counts[1]);
		System.out.println("Entropy counts < 30 " + counts[2]);
		System.out.println("Entropy counts > 30 " + counts[3]);

	}

}
