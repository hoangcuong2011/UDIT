package cat.models.stats;

/**
 * Container for statisics on the E-Step
 * 
 * @author Kuzman
 * 
 * 
 */
public class AgreeEStepStats extends EStepStats {
	public double logLikelihoodF = 0.0;

	public double logLikelihoodB = 0.0;

	public int numSents = 0;

	long start = -1;

	long total = 0;

	public ProjectionStats pStats;

	public void add(AgreeEStepStats other) {
		logLikelihoodF += other.logLikelihoodF;
		logLikelihoodB += other.logLikelihoodB;
		numSents += other.numSents;
		if (pStats == null) {
			pStats = other.pStats;
		} else {
			pStats.add(other.pStats);

		}
	}

	public void startTime() {
		start = System.currentTimeMillis();
	}

	public void stopTime() {
		total += System.currentTimeMillis() - start;
	}

	public String makeVerbose(AgreeEStepStats prev) {
		StringBuffer s = new StringBuffer();
		s.append("\t-log(LF)="
				+ cat.common.StaticTools.prettyPrint(-logLikelihoodF,
						"0.000E00", 9));
		s.append("\t-log(LB)="
				+ cat.common.StaticTools.prettyPrint(-logLikelihoodB,
						"0.000E00", 9));
		s.append(" diffF="
				+ cat.common.StaticTools.prettyPrint(logLikelihoodF
						- prev.logLikelihoodF, "0.000E00", 9));
		s.append(" diffB="
				+ cat.common.StaticTools.prettyPrint(logLikelihoodB
						- prev.logLikelihoodB, "0.000E00", 9));
		s.append(" time=" + cat.common.StaticTools.formatTime(total));
		s.append("\n Projection Stats =" + pStats.makeVerbose());
		return s.toString();
	}

}
