package cat.models.stats;

public class ProjectionStats {

	SingleProjectionStat[] stats;

	int nrIterations;

	public ProjectionStats(int nrIterations) {
		this.nrIterations = nrIterations;
		stats = new SingleProjectionStat[nrIterations];
		for (int i = 0; i < nrIterations; i++) {
			stats[i] = new SingleProjectionStat();
		}
	}

	public void addViolation(double violation, int iteration) {
		stats[iteration].totalViolation = violation;
	}

	public void addForwardKL(double forwardKL, int iteration) {
		stats[iteration].forwardKL = forwardKL;
	}

	public void addBackwardKL(double backwardKL, int iteration) {
		stats[iteration].backwardKL = backwardKL;
	}

	public String makeVerbose() {
		StringBuffer s = new StringBuffer();
		for (int i = 0; i < nrIterations; i++) {
			SingleProjectionStat ss = stats[i];
			s.append("ITer " + i);
			s.append("  Violation= "
					+ cat.common.StaticTools.prettyPrint(ss.totalViolation,
							"0.000E00", 9));
			s.append("  F KL ="
					+ cat.common.StaticTools.prettyPrint(ss.forwardKL,
							"0.000E00", 9));
			s.append("  B KL= "
					+ cat.common.StaticTools.prettyPrint(ss.backwardKL,
							"0.000E00", 9));
			s.append("\n");
		}
		return s.toString();
	}

	public void add(ProjectionStats newStats) {
		for (int i = 0; i < nrIterations; i++) {
			SingleProjectionStat total = stats[i];
			SingleProjectionStat single = newStats.stats[i];
			total.totalViolation += single.totalViolation;
			total.forwardKL += single.forwardKL;
			total.backwardKL += single.backwardKL;
		}
	}

	class SingleProjectionStat {
		public double totalViolation = 0;

		public double forwardKL;

		public double backwardKL;
	}

}
