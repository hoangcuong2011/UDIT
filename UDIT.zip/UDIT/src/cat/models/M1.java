package cat.models;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import cat.alignmnets.Alignment;
import cat.alignmnets.AlignmentEvaluator;
import cat.alignmnets.AlignmentsSet;
import cat.corpus.BilingualCorpus;
import cat.models.stats.EStepStats;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

/**
 * Implementation of IBM Model 1
 * @author javg
 *
 */
public class M1 extends AbstractModel {

    protected SparseCountTable _count;
    public SparseTranslationTable _tb;
    public double _smoothing = 0.0;
    public ArrayList<Float> pd = null;

    public BilingualCorpus getCorpus() {
        return _corpus;
    }

    public String getName() {
        return "IBM Model 1";
    }

    public M1() {
    }

    public M1(BilingualCorpus corpus) throws IOException {
        this(corpus, 0);
    }
    public M1(BilingualCorpus corpus, ArrayList<Float> pd) throws IOException {
        this(corpus, 0, pd);  
    }

    public M1(BilingualCorpus corpus, SparseTranslationTable tb) throws FileNotFoundException, IOException {
        this(corpus, tb, 0);
    }
    public M1(BilingualCorpus corpus, SparseTranslationTable tb, ArrayList<Float> pd) throws FileNotFoundException, IOException {
        this(corpus, tb, 0, pd);
    }

    public M1(BilingualCorpus corpus, double smoothing) throws IOException {
        this(corpus, null, smoothing);        
    }
    public M1(BilingualCorpus corpus, double smoothing, ArrayList<Float> pd) throws IOException {
        this(corpus, null, smoothing, pd);        
    }

    public M1(BilingualCorpus corpus, SparseTranslationTable tb,
            double smoothing) throws FileNotFoundException, IOException {
        System.out.println("Started the Initialization of " + getName()
                + " reusing translation table");
        _corpus = corpus;
        _sourceSize = corpus.getSourceSize();
        _foreignSize = corpus.getForeignSize();
        _nSentences = corpus.getNumberOfTrainingSentences();
        
        
        if (tb == null) {
            _tb = new SparseTranslationTable(corpus);
        } else {
            _tb = tb;
        }
        _smoothing = smoothing;
        System.out.println("Ended the Initialization of " + getName());
    }
    public M1(BilingualCorpus corpus, SparseTranslationTable tb,
            double smoothing, ArrayList<Float> pd) throws FileNotFoundException, IOException {
        System.out.println("Started the Initialization of " + getName()
                + " reusing translation table");
        _corpus = corpus;
        _sourceSize = corpus.getSourceSize();
        _foreignSize = corpus.getForeignSize();
        _nSentences = corpus.getNumberOfTrainingSentences();
        
        this.pd = pd;
        if (tb == null) {
            _tb = new SparseTranslationTable(corpus, pd);
        } else {
            _tb = tb;
        }
        _smoothing = smoothing;
        System.out.println("Ended the Initialization of " + getName());
    }

    public void printStamp(PrintStream file) {
        file.println("Smooth value: " + _smoothing);
        file.println("Iterations: " + _trainingIterations);
    }

    public void saveModel(String directory) {
        super.saveModel(directory);
        _tb.saveTable(directory);
    }

    public static M1 loadModel(BilingualCorpus corpus, String directory) throws IOException {
        M1 model = new M1();
        
        
        if (!corpus.checkDescription(directory)) {
            System.out.println("Corpus is not the same");
            System.exit(1);
        }
        model._corpus = corpus;        
        model._sourceSize = corpus.getSourceSize();
        model._foreignSize = corpus.getForeignSize();
        model._nSentences = corpus.getNumberOfTrainingSentences();        
        model._tb = SparseTranslationTable.LoadTranslationTable(corpus, directory);
        model._trained = false;
        return model;
    }

    /**
     * 
     */
    public double[][] makeProbCache(int[] f, int[] s) {
        // TODO Why do we need this?
        final int sSize = s.length;
        final int fSize = f.length;
        // cache the probabilities for speed.
        double[][] probCache = new double[fSize][sSize + 1];
        for (int fi = 0; fi < fSize; fi++) {
            for (int si = 0; si < sSize; si++) {
                probCache[fi][si] = _tb.getProbability(s[si], f[fi]);
            }

            double val = _tb.getNullProbability(f[fi]);
            probCache[fi][sSize] = val;
        }
        return probCache;
    }
    
    /**
     * Hoang Cuong - slight modification
     */
    
    
    public ArrayList<Double> updatePD1() {
        ArrayList<Double> arrList = new ArrayList<Double>();
        for (int i = 0; i < _corpus.getNumberOfTrainingSentences(); i++) {
            int[] s = _corpus.getSourceSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int sSize = s.length;
            int[] f = _corpus.getForeignSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int fSize = f.length;
            double forwardProbCachePD1 = loadProbCachePd1(f, s);            
            arrList.add(i, forwardProbCachePD1);
        }
        return arrList;
    }
    
    /**
     * 
     */
    public double loadProbCachePd1(int[] f, int[] s) {
        // TODO Why do we need this?
        final int sSize = s.length;
        final int fSize = f.length;
        // cache the probabilities for speed.
        double total = 1.0;
        double[][] probCache = new double[fSize][sSize + 1];
        for (int fi = 0; fi < fSize; fi++) {
            double sum = 0.0;
            for (int si = 0; si < sSize; si++) {
                probCache[fi][si] = _tb.getProbability(s[si], f[fi]);
                sum+=probCache[fi][si];
            }

            double val = _tb.getNullProbability(f[fi]);
            probCache[fi][sSize] = val;
            sum+=val;
            total*=sum;
        }
        return total;
    }

    /**
     * 
     */
    public double getNullPhrasePosterior(int phraseNumber, byte phraseSource,
            int[] foreingSentence, int[] sourceSentence, int startForeignIndex,
            int endForeignIndex) {
        double observationProb = 1;
        for (int foreignIndex = startForeignIndex; foreignIndex <= endForeignIndex; foreignIndex++) {
            observationProb *= _tb.getNullProbability(foreingSentence[foreignIndex]);
        }
        return observationProb;
    }

    /**
     * 
     */
    public double getPhrasePosterior(int phraseNumber, byte phraseSource,
            int[] foreingSentence, int[] sourceSentence, int startSourceIndex,
            int endSourceIndex, int startForeignIndex, int endForeignIndex) {
        double observationProb = 1;
        for (int foreignIndex = startForeignIndex; foreignIndex <= endForeignIndex; foreignIndex++) {
            double probAux = 0;
            for (int sourceIndex = startSourceIndex; sourceIndex <= endSourceIndex; sourceIndex++) {
                probAux += _tb.getProbability(sourceSentence[sourceIndex],
                        foreingSentence[foreignIndex]);
            }
            observationProb *= probAux;
        }
        double divider = Math.pow((endSourceIndex - startSourceIndex + 1),
                (endForeignIndex - startForeignIndex + 1));
        observationProb = observationProb / divider;
        return observationProb;
    }

    /**
     * Builds the posterior probability of a given sentence. Dependes on the
     * methods calculateProbability and getNullProbability to calculate the
     * specific probabilities.
     */
    public double calculatePosteriors(int[] source, int[] foreign,
            double[][] posteriors, double[][] probCache) {
        double likelihood = 0;
        for (int f = 0; f < foreign.length; f++) {
            double sum = 0.0;
            for (int s = 0; s < source.length; s++) {
                sum += probCache[f][s];
            }
            // Assume there is a null word in each sentence
            // This might be changed to test
            sum += probCache[f][source.length];
            assert !Double.isNaN(sum) : getName() + " calclute posterior " + ": Sum is NaN";
            if (sum != 0) { // If sum = 0 don't divide
                likelihood += Math.log(sum);
                for (int s = 0; s < source.length; s++) {
                    double newProb = probCache[f][s] / sum;
                    posteriors[s][f] = newProb;
                }
                double abc = probCache[f][source.length];
                double newNullProb = probCache[f][source.length] / sum;
                posteriors[source.length][f] = newNullProb;
            } else {
                System.out.println(getName() + " calculatePosterior"
                        + ": Sum is zero not calculating entry");
            }
        }
        return likelihood;
    }

    public EStepStats eStep() {
        double totalLikelihood = 0.0;
        clearCounts();
        for (int i = 0; i < _nSentences; i++) {
            // Calculate Posterirors
            int[] s = _corpus.getSourceSentence(i, BilingualCorpus.TRAIN_CORPUS);
            int[] f = _corpus.getForeignSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            double[][] posteriors = new double[s.length + 1][f.length];
            double[][] probCache = makeProbCache(f, s);
            totalLikelihood += calculatePosteriors(s, f, posteriors, probCache);
            // Add counts
            addCounts(pd.get(i), s, f, posteriors);
        }
        EStepStats d = new EStepStats();
        d.logLikelihood = totalLikelihood;
        d.numSents = _nSentences;
        return d;
    }

    public void initializeTrain() {
        _count = new SparseCountTable(_corpus, _smoothing);
    }

    public void finalizeTrain() {
        _count = null;
    }

    public void clearCounts() {
        _count.initializeToSmoothingValue();
    }

    public void addCounts(float pd, int[] source, int[] foreign, double[][] posteriors) {
        for (int f = 0; f < foreign.length; f++) {
            for (int s = 0; s < source.length; s++) {
                _count.addToCount(source[s], foreign[f], pd * posteriors[s][f]);
            }
            _count.addToNullCount(foreign[f], (pd) * posteriors[source.length][f]);
        }
    }

    public void updateTranslationProbabilities(SparseTranslationTable tb,
            SparseCountTable count) {
        tb.clear();
        int numZeroNorm = 0;
        int[] zeroNormSents = new int[5];
        for (int si = 0; si < _sourceSize; si++) {
            // Iterate over all non zero counts devide by their sum and add to
            // TT table
            int[] poss = count.getNotZeroCountsByWord(si);
            double lambdaE = count.getNormalizing(si);
            assert !Double.isNaN(lambdaE) : "lambdaE is NaN";
            if (lambdaE > 1.0e-200) {
                // System.out.println("Start updating tb " + poss.length);
                for (int pos = 0; pos < poss.length; pos++) {
                    double prob = count.getCountByIndex(poss[pos]) / lambdaE;
                    tb.setProbabilityByPos(poss[pos], prob);
                }
            } else {
                if (zeroNormSents.length > numZeroNorm) {
                    zeroNormSents[numZeroNorm] = si;
                }
                numZeroNorm += 1;
            }
        }
        if (numZeroNorm > 0) {
            System.out.print(getName() + " Normalizer close to zero in "
                    + numZeroNorm + "cases ");
            System.out.println(((100.0 * numZeroNorm) / _sourceSize) + "%");
            System.out.println("First few are ");
            for (int i = 0; i < numZeroNorm && i < zeroNormSents.length; i++) {
                System.out.print(" " + zeroNormSents[i]);
            }
            System.out.println();
        }
        double nullNormalizer = count.getNormalizingNull();
        assert !Double.isNaN(nullNormalizer);
        for (int j = 0; j < _foreignSize; j++) {
            double aux = count.getNullCounts(j);
            assert !Double.isNaN(aux) : "UpdateTranslationProbabilities: Null Counts is NaN";
            if (aux < 1.0e-200 || nullNormalizer < 1.0e-200) {
                tb.setNullProbability(j, 0);
            } else {
                tb.setNullProbability(j, aux / nullNormalizer);
            }
        }
    }

    public void mStep() {
        updateTranslationProbabilities(_tb, _count);
    }

    public double calculateProbability(int sourceWord, int foreignWord,
            int sourcePos, int foreignPos, int sourceLen, int foreignLen) {
        return _tb.getProbability(sourceWord, foreignWord);
    }

    public double getNullProbability(int foreignWord, int foreignPos,
            int sourceLen, int foreignLen) {
        return _tb.getNullProbability(foreignWord);
    }

    public Alignment viterbiAlignment(int sentenceNumber, byte sentenceSource) {
        int sourceLen = _corpus.getSourceSentenceLength(sentenceNumber,
                sentenceSource);
        int foreignLen = _corpus.getForeignSentenceLength(sentenceNumber,
                sentenceSource);
        Alignment a = new Alignment(sentenceNumber, sentenceSource, sourceLen,
                foreignLen);
        int[] source = _corpus.getSourceSentence(sentenceNumber, sentenceSource);
        int[] foreign = _corpus.getForeignSentence(sentenceNumber,
                sentenceSource);
        double[][] posteriors = new double[sourceLen + 1][foreignLen];
        double[][] probCache = makeProbCache(foreign, source);
        calculatePosteriors(source, foreign, posteriors, probCache);
        for (int j = 0; j < foreign.length; j++) {
            int pos = 0;
            double max = 0;
            for (int i = 0; i < source.length; i++) {
                double prob = posteriors[i][j];
                // System.out.println("Posteriro" + i +" " + j+ " "+prob);
                if (prob > max) {
                    max = prob;
                    pos = i;
                }
            }
            double nullProb = posteriors[sourceLen][j];
            if (max > nullProb) {
                a.add(pos, j);
            }
        }
        return a;
    }

    public Alignment posteriorDecodingAlignment(int sentenceNumber,
            byte sentenceSource, float treshhold) {
        int sourceLen = _corpus.getSourceSentenceLength(sentenceNumber,
                sentenceSource);
        int foreignLen = _corpus.getForeignSentenceLength(sentenceNumber,
                sentenceSource);
        Alignment a = new Alignment(sentenceNumber, sentenceSource, sourceLen,
                foreignLen);
        int[] source = _corpus.getSourceSentence(sentenceNumber, sentenceSource);
        int[] foreign = _corpus.getForeignSentence(sentenceNumber,
                sentenceSource);
        double[][] probCache = makeProbCache(foreign, source);
        double[][] posteriors = new double[sourceLen + 1][foreignLen];
        calculatePosteriors(source, foreign, posteriors, probCache);
        for (int j = 0; j < foreign.length; j++) {
            for (int i = 0; i < source.length; i++) {
                if (posteriors[i][j] > treshhold) {
                    a.add(i, j);
                }
            }
        }
        return a;
    }

}
