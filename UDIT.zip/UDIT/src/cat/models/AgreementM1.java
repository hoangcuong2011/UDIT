package cat.models;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import cat.alignmnets.Alignment;
import cat.alignmnets.AlignmentEvaluator;
import cat.alignmnets.AlignmentsSet;
import cat.alignmnets.AlignmentEvaluator.Evaluation;
import cat.common.Common;
import cat.common.StaticTools;
import cat.corpus.BilingualCorpus;
import cat.models.stats.AgreeEStepStats;
import cat.models.stats.EStepStats;
import cat.models.stats.ProjectionStats;
import java.io.File;
import java.util.ArrayList;

public class AgreementM1 extends AbstractModel {

    public M1 forward;
    public M1 backward;
    double epsilon;
    int projectionIterations;
    boolean _trained = false;
    
    
    public ArrayList<Float> pd = null;

    
    /**
     * Hoang Cuong - slight modification
     */
    
    public double loadProbCachePd1(int[] f, int[] s) {
        // TODO Why do we need this?
        final int sSize = s.length;
        final int fSize = f.length;
        // cache the probabilities for speed.
        double total = 1.0;
        double[][] probCache = new double[fSize][sSize + 1];
        for (int fi = 0; fi < fSize; fi++) {
            double sum = 0.0;
            for (int si = 0; si < sSize; si++) {
                probCache[fi][si] = forward._tb.getProbability(s[si], f[fi]);
                sum+=probCache[fi][si];
            }

            double val = forward._tb.getNullProbability(f[fi]);
            probCache[fi][sSize] = val;
            sum+=val;
            total*=sum;
        }
        return total;
    }

    
    /**
     * Hoang Cuong - slight modification
     */
    
    public ArrayList<Double> updatePD1() {
//        This is an immediate step
        ArrayList<Double> arrList = new ArrayList<Double>();
        for (int i = 0; i < forward._corpus.getNumberOfTrainingSentences(); i++) {
            int[] s = forward._corpus.getSourceSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int sSize = s.length;
            int[] f = forward._corpus.getForeignSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int fSize = f.length;
            double forwardProbCachePD1 = loadProbCachePd1(f, s);            
            arrList.add(i, forwardProbCachePD1);
        }
        return arrList;
    }
    
    public AgreementM1(BilingualCorpus forwardCorpus,
            BilingualCorpus backwardCorpus, double epsilon, int projectionIterations, ArrayList<Float> pd) throws IOException {
        this(forwardCorpus, backwardCorpus, epsilon, 0, projectionIterations, pd);
    }

    public AgreementM1(BilingualCorpus forwardCorpus,
            BilingualCorpus backwardCorpus, double epsilon, double smooth, int projectionIterations, ArrayList<Float> pd) throws IOException {
        this.epsilon = epsilon;
        this.projectionIterations = projectionIterations;
        this._corpus = forwardCorpus;
        forward = new M1(forwardCorpus, smooth, pd);
        backward = new M1(backwardCorpus, smooth, pd);
    }

    AgreementM1() {
    }

    public void saveModel(String directory) {
        forward.saveModel(directory + "forward");
        backward.saveModel(directory + "backward");
        try {
            PrintStream file = new PrintStream(new FileOutputStream(directory + "epsilon"));
            file.println(projectionIterations);
            file.println(epsilon);
        } catch (FileNotFoundException e) {
            System.out.println(getName() + ": Could not save model");
            System.exit(-1);
        }
    }

    public static AgreementM1 loadModel(BilingualCorpus corpus, String directory) {
        AgreementM1 model = new AgreementM1();
        try {
            BufferedReader file = new BufferedReader(new FileReader(directory + "epsilon"));
            model.projectionIterations = Integer.parseInt(file.readLine());
            model.epsilon = Double.parseDouble(file.readLine());
            System.out.println("Reading Forward: " + directory + "forward");
            model.forward = M1.loadModel(corpus, directory + "forward");
            System.out.println("Reading Forward: " + directory + "backward");
            model.backward = M1.loadModel(corpus.reverse(), directory
                    + "backward");
        } catch (FileNotFoundException e) {
            System.out.println(model.getName() + ": Could not read model file not found "
                    + e.toString());
            System.exit(-1);
        } catch (NumberFormatException e) {
            System.out.println(model.getName() + ": Could not read model number conversion exception"
                    + e.toString());
            System.exit(-1);

        } catch (IOException e) {
            System.out.println(model.getName() + ": Could not read model"
                    + e.toString());
            System.exit(-1);
        }
        return model;
    }

    public String getName() {
        return "Agreement Model 1";
    }

    // Calcultes the projection statistics for just one instance
    public ProjectionStats projectPosteriors(double[][][] posteriors, int sSize, int fSize) {
        ProjectionStats stats = new ProjectionStats(projectionIterations);



        double[][] posteriorsF = posteriors[0];
        double[][] posteriorsB = posteriors[1];

        double[][] posteriorFOriginal = StaticTools.copyMatrix(posteriorsF, sSize + 1, fSize);
        double[][] posteriorBOriginal = StaticTools.copyMatrix(posteriorsB, fSize + 1, sSize);


        double phi[][] = new double[sSize][fSize];
        double oldPhi[][] = new double[sSize][fSize];
        //System.out.println("new instance ------------------------------");
        for (int grI = 0; grI < projectionIterations; grI++) {
            double lRate = 10;
            if (grI == 0) {
                lRate = 1;
            }
            double totalViolation = 0;
            set1to2(oldPhi, phi);
            double[][] oldPosteriorF = StaticTools.copyMatrix(posteriorsF, sSize + 1, fSize);
            double[][] oldPosteriorB = StaticTools.copyMatrix(posteriorsB, fSize + 1, sSize);
            for (int i = 0; i < 20; i++) {
                totalViolation = 0;
                for (int fi = 0; fi < fSize; fi++) {
                    for (int si = 0; si < sSize; si++) {
                        // Update phi and lambda
                        double ePsi = posteriorsF[si][fi] - posteriorsB[fi][si];
                        double phiUpdate = lRate * (-ePsi);
                        totalViolation += Math.abs(-ePsi);
                        double newPhi = phiUpdate + phi[si][fi];

                        posteriorsF[si][fi] = posteriorFOriginal[si][fi]
                                * Math.exp(newPhi);
                        posteriorsB[fi][si] = posteriorBOriginal[fi][si]
                                * Math.exp(-newPhi);
                        phi[si][fi] = newPhi;
                    }
                }
                double oldTotalViolation = totalViolation;

                // Renormalizing
                posteriorsF = Common.normalize(posteriorsF, fSize, sSize + 1);
                posteriorsB = Common.normalize(posteriorsB, sSize, fSize + 1);
                double newTotalViolation = 0;
                for (int fi = 0; fi < fSize; fi++) {
                    for (int si = 0; si < sSize; si++) {
                        double ePsi = posteriorsF[si][fi] - posteriorsB[fi][si];
                        newTotalViolation += Math.abs(-ePsi);
                    }
                }

                if (newTotalViolation <= oldTotalViolation) {
                    set1to2(oldPhi, phi);
                    oldTotalViolation = newTotalViolation;
                    //System.out.println("i:"+i+" lRate: "+lRate);
                    //System.out.println("i:"+i+" ||phi||^2: "+normSquared(phi));
                    //System.out.println("i:"+i+" totalViolation: "+oldTotalViolation+" -> "+newTotalViolation);
                    break;
                } else {
                    set1to2(phi, oldPhi);
                    set1to2(posteriorsF, oldPosteriorF);
                    set1to2(posteriorsB, oldPosteriorB);
                    lRate = lRate / 2;
                }
            }

            // Adding Stats
            stats.addViolation(totalViolation, grI);
            // Calculate thw KL(q|p) which is what we are minimizing
            stats.addForwardKL(cat.common.StaticTools.KLDistance(posteriorsF,
                    posteriorFOriginal, sSize + 1, fSize), grI);
            stats.addBackwardKL(cat.common.StaticTools.KLDistance(posteriorsB,
                    posteriorBOriginal, fSize + 1, sSize), grI);
        }
        posteriors[0] = posteriorsF;
        posteriors[1] = posteriorsB;
        return stats;
    }

    public void set1to2(double[][] to, double[][] from) {
        for (int i = 0; i < to.length; i++) {
            for (int j = 0; j < to[i].length; j++) {
                to[i][j] = from[i][j];
            }
        }
    }

    public double normSquared(double[][] mat) {
        double res = 0;
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                res += mat[i][j] * mat[i][j];
            }
        }
        return res;
    }
    
    public AgreeEStepStats eStep() {
        double totalLikelihoodF = 0;
        double totalLikelihoodB = 0;
        forward.clearCounts();
        backward.clearCounts();
        AgreeEStepStats d = new AgreeEStepStats();
        ProjectionStats totalPStats = new ProjectionStats(projectionIterations);
        for (int i = 0; i < forward._corpus.getNumberOfTrainingSentences(); i++) {
            int[] s = forward._corpus.getSourceSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int sSize = s.length;
            int[] f = forward._corpus.getForeignSentence(i,
                    BilingualCorpus.TRAIN_CORPUS);
            final int fSize = f.length;
            double[][] forwardProbCache = forward.makeProbCache(f, s);
            double[][] backwardProbCache = backward.makeProbCache(s, f);
            // indexed by[si][fi] sSize corresponds to null word probability
            double[][] posteriorsF = new double[sSize + 1][fSize];
            totalLikelihoodF += forward.calculatePosteriors(s, f, posteriorsF, forwardProbCache);
            // indexed by[fi][si] fSize corresponds to null word probability
            double[][] posteriorsB = new double[fSize + 1][sSize];
            totalLikelihoodB += backward.calculatePosteriors(f, s, posteriorsB, backwardProbCache);
            double[][][] posteriors = {posteriorsF, posteriorsB};
            totalPStats.add(projectPosteriors(posteriors, sSize, fSize));
            posteriorsF = posteriors[0];
            posteriorsB = posteriors[1];
            forward.addCounts(pd.get(i), s, f, posteriorsF);
            backward.addCounts(pd.get(i), f, s, posteriorsB);
        }
        d.logLikelihoodF = totalLikelihoodF;
        d.logLikelihoodB = totalLikelihoodB;
        d.numSents = forward._corpus.getNumberOfTrainingSentences();
        d.pStats = totalPStats;
        return d;
    }
    
   

    // Its here just because of the stats. Should be removed.
    public void train(int currentIter, int iterations) {
        if (1 != 0) {
            _trainingIterations = iterations;
            System.out.println("Starting " + getName() + " Training");
            initializeTrain();
        }

        AgreeEStepStats d_pd1 = new AgreeEStepStats(), old = new AgreeEStepStats();
        // /DEBUG CODE
        System.out.println("Iteration " + (currentIter + 1));
        System.out.flush();
        // E-Step
        System.out.println(" e Step");
        d_pd1.startTime();
        d_pd1.add(eStep());
        d_pd1.stopTime();
        System.out.println(d_pd1.makeVerbose(old));
        // M-Step
        old = d_pd1;
        d_pd1 = new AgreeEStepStats();
        mStep();
        System.out.println(" m Step");
        System.out.flush();
        if (currentIter == iterations - 1) {
            setTrained();
            finalizeTrain();
            System.out.println();
        }
    }

    public void setTrained() {
        _trained = true;
        forward.setTrained();
        backward.setTrained();
    }

    public void mStep() {
        forward.mStep();
        backward.mStep();
    }

    public Alignment posteriorDecodingAlignment(int sentenceNumber,
            byte sentenceSource, float treshhold) {
        return forward.posteriorDecodingAlignment(sentenceNumber,
                sentenceSource, treshhold);
    }

    public Alignment viterbiAlignment(int sentenceNumber, byte sentenceSource) {
        return forward.viterbiAlignment(sentenceNumber, sentenceSource);
    }

    public void initializeTrain() {
        forward.initializeTrain();
        backward.initializeTrain();
    }

    public void finalizeTrain() {
        forward.finalizeTrain();
        backward.finalizeTrain();
    }

    // TODO fornow just use the forward model
    public double getNullPhrasePosterior(int phraseNumber, byte phraseSource,
            int[] foreingSentence, int[] sourceSentence, int startForeignIndex,
            int endForeignIndex) {
        return forward.getNullPhrasePosterior(phraseNumber, phraseSource,
                foreingSentence, sourceSentence, startForeignIndex,
                endForeignIndex);
    }

    // TODO fornow just use the forward model
    public double getPhrasePosterior(int phraseNumber, byte phraseSource,
            int[] foreingSentence, int[] sourceSentence, int startSourceIndex,
            int endSourceIndex, int startForeignIndex, int endForeignIndex) {
        return forward.getPhrasePosterior(phraseNumber, phraseSource,
                foreingSentence, sourceSentence, startSourceIndex,
                endSourceIndex, startForeignIndex, endForeignIndex);
    }
}
