package cat.common;

public class Pair<O1, O2> {
	O1 _first;

	O2 _second;

	public O1 first() {
		return _first;
	}

	public O2 second() {
		return _second;
	}

	public Pair(O1 first, O2 second) {
		_first = first;
		_second = second;
	}

}
