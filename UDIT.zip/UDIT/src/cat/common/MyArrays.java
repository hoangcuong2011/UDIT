package cat.common;

public class MyArrays {

	public static void printDoubleArray(double[] array, String arrayName) {
		System.out.println(arrayName);
		for (int i = 0; i < array.length; i++) {
			System.out.print(" " + array[i] + " ");
		}
		System.out.println();
	}

	public static void printDoubleArray(double[][] array, String arrayName,
			int size1, int size2) {
		System.out.println(arrayName);
		for (int i = 0; i < size1; i++) {
			for (int j = 0; j < size2; j++) {
				System.out.print(" " + array[i][j] + " ");

			}
			System.out.println();
		}
		System.out.println();
	}

	public static void printIntArray(int[] array, String arrayName) {
		System.out.println(arrayName);
		for (int i = 0; i < array.length; i++) {
			System.out.print(" " + array[i] + " ");
		}
		System.out.println();
	}

}
