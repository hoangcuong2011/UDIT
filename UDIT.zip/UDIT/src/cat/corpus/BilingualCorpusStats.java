package cat.corpus;

import java.io.IOException;

public class BilingualCorpusStats {

	public static void computeWordFreqs(BilingualCorpus test,
			BilingualCorpus train) {
		int sourceCommonWords = 0, sourceRareWords = 0, sourceUnknowWords = 0;
		int foreignCommonWords = 0, foreignRareWords = 0, foreignUnknowWords = 0;
		int sourceCommonTypes = 0, sourceRareTypes = 0, sourceUnknowTypes = 0;
		int foreignCommonTypes = 0, foreignRareTypes = 0, foreignUnknowTypes = 0;
		for (String sourceType : test._vocabNamesSource) {
			int testSourceTypePos = test._vocabSource.get(sourceType);
			if (train._vocabSource.containsKey(sourceType)) {
				int trainSourceTypePos = train._vocabSource.get(sourceType);
				if (train.sourceRareWord(trainSourceTypePos, 20)) {
					sourceRareTypes++;
					sourceRareWords += test._sourceWordsCounts
							.get(testSourceTypePos);
				} else {
					sourceCommonTypes++;
					sourceCommonWords += test._sourceWordsCounts
							.get(testSourceTypePos);
				}
			} else {
				sourceUnknowTypes++;
				sourceUnknowWords += test._sourceWordsCounts
						.get(testSourceTypePos);
			}

		}

		for (String foreignType : test._vocabNamesForeign) {
			int testForeignTypePos = test._vocabForeign.get(foreignType);
			if (train._vocabForeign.containsKey(foreignType)) {
				int trainForeignTypePos = train._vocabForeign.get(foreignType);
				if (train.foreignRareWord(trainForeignTypePos, 20)) {
					foreignRareTypes++;
					foreignRareWords += test._foreignWordsCounts
							.get(testForeignTypePos);
				} else {
					foreignCommonTypes++;
					foreignCommonWords += test._foreignWordsCounts
							.get(testForeignTypePos);
				}
			} else {
				foreignUnknowTypes++;
				foreignUnknowWords += test._foreignWordsCounts
						.get(testForeignTypePos);
			}
		}
		int sourceTotalTypes = sourceCommonTypes + sourceRareTypes
				+ sourceUnknowTypes;
		int foreignTotalTypes = foreignCommonTypes + foreignRareTypes
				+ foreignUnknowTypes;
		int sourceTotalWords = sourceCommonWords + sourceRareWords
				+ sourceUnknowWords;
		int foreignTotalWords = foreignCommonWords + foreignRareWords
				+ foreignUnknowWords;
		System.out.println("Source Words: Total " + sourceTotalWords
				+ " common " + (sourceCommonWords * 100.0 / sourceTotalWords)
				+ " rare " + (sourceRareWords * 100.0 / sourceTotalWords)
				+ " Unknown " + (sourceUnknowWords * 100.0 / sourceTotalWords));
		System.out.println("Source Types: Total " + sourceTotalTypes
				+ " common " + (sourceCommonTypes * 100.0 / sourceTotalTypes)
				+ " rare " + (sourceRareTypes * 100.0 / sourceTotalTypes)
				+ " Unknown " + (sourceUnknowTypes * 100.0 / sourceTotalTypes));
		System.out.println("Foreign Words: Total " + foreignTotalWords
				+ " common " + (foreignCommonWords * 100.0 / foreignTotalWords)
				+ " rare " + (foreignRareWords * 100.0 / foreignTotalWords)
				+ " Unknown "
				+ (foreignUnknowWords * 100.0 / foreignTotalWords));
		System.out.println("Foreign Types: Total " + foreignTotalTypes
				+ " common " + (foreignCommonTypes * 100.0 / foreignTotalTypes)
				+ " rare " + (foreignRareTypes * 100.0 / foreignTotalTypes)
				+ " Unknown "
				+ (foreignUnknowTypes * 100.0 / foreignTotalTypes));
	}

	// Output test sentences
	public static void sentenceStats(BilingualCorpus test) {
		System.out.println("Source "
				+ " max "
				+ test.getMaxSourceLen()
				+ " avg "
				+ (test.getTotalSourceWords() * 1.0 / test
						.getNumberOfTrainingSentences()));
		System.out.println("Foreign "
				+ " max "
				+ test.getMaxForeignLen()
				+ " avg "
				+ (test.getTotalForeignWords() * 1.0 / test
						.getNumberOfTrainingSentences()));

	}

	/**
	 * Computes the statitics of a Translation Test set against the used test.
	 * Note that the test set should not be included in the training set
	 * 
	 * @throws IOException
	 * 
	 */
	public static void statsOfTestSet(String trainingCorpusParams,
			String testCorpusParams) throws IOException {
		BilingualCorpus train = BilingualCorpus.getCorpusFromFileDescription(
				trainingCorpusParams, Integer.MAX_VALUE);
		BilingualCorpus test = BilingualCorpus.getCorpusFromFileDescription(
				testCorpusParams, Integer.MAX_VALUE);
		computeWordFreqs(test, train);
		sentenceStats(test);
		System.out.print("Sentence stats on training");
		sentenceStats(train);

	}

	public static void main(String[] args) throws IOException {
		statsOfTestSet(args[0], args[1]);
	}

}
