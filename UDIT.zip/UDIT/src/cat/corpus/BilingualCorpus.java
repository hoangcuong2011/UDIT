package cat.corpus;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;

import cat.alignmnets.Alignment;
import cat.alignmnets.AlignmentsSet;
import gnu.trove.map.hash.TIntIntHashMap;
import gnu.trove.map.hash.TObjectIntHashMap;

public class BilingualCorpus {

    // Debug to see how much corpus are being created
    public static int counter = 0;
    public static final byte TRAIN_CORPUS = 0;
    public static final byte TEST_CORPUS = 1;
    public static final byte DEV_CORPUS = 2;
    // Class that knows how to assing an unique ID to a pair source foreing
    // TODO see where it should go
    public Reference ref;
    // Contains an integer for each word string
    String _name;
    public TObjectIntHashMap<String> _vocabSource;
    public ArrayList<String> _vocabNamesSource;
    public TObjectIntHashMap<String> _vocabForeign;
    public ArrayList<String> _vocabNamesForeign;
    int _maxSourceLen, _maxForeignLen;
    public TIntIntHashMap _sourceWordsCounts;
    public TIntIntHashMap _foreignWordsCounts;
    // TrainData contains the training instances for both languages
    public ArrayList<int[]> _trainSourceSentences;
    public ArrayList<int[]> _trainForeignSentences;
    int _maxTrainingSentences;
    int _nrTrainingSentences;
    int _maxSentenceSize;
    int _discardedSentences;
    // Testing data. May be null
    public ArrayList<int[]> _testSourceSentences;
    public ArrayList<int[]> _testForeignSentences;
    public AlignmentsSet _gold;
    // Development Data might be null
    public ArrayList<int[]> _devSourceSentences;
    public ArrayList<int[]> _devForeignSentences;
    public AlignmentsSet _devGold;
    // TODO maybe this is not the best place
    // Empirical fertilities created using the dev set
    double[] _foreignFertilities;
    public double[] _sourceFertilities;
    int _sourceSize;
    int _foreignSize;
    // Prefixes of each language used when outputing corpus for moses and other
    // stuff
    String _sourceSufix;
    String _foreignSufix;

    public void trim() {
        _vocabSource = null;
        _vocabNamesSource = null;
        _vocabForeign = null;
        _vocabNamesForeign = null;
        _sourceWordsCounts = null;
        _foreignWordsCounts = null;
        _foreignFertilities = null;
        _sourceFertilities = null;
        _sourceWordsCounts = null;
        _foreignWordsCounts = null;
    }

    public BilingualCorpus(int maxNumberOfSentences, String name,
            String sourcePrefix, String foreignPrefix) {
        _name = name;
        _vocabForeign = new TObjectIntHashMap<String>();
        _vocabSource = new TObjectIntHashMap<String>();
        _vocabNamesForeign = new ArrayList<String>();
        _vocabNamesSource = new ArrayList<String>();
        _maxTrainingSentences = maxNumberOfSentences;
        _trainSourceSentences = new ArrayList<int[]>();
        _trainForeignSentences = new ArrayList<int[]>();
        _testSourceSentences = new ArrayList<int[]>();
        _testForeignSentences = new ArrayList<int[]>();
        _devSourceSentences = new ArrayList<int[]>();
        _devForeignSentences = new ArrayList<int[]>();
        _sourceSufix = sourcePrefix;
        _foreignSufix = foreignPrefix;
        _sourceWordsCounts = new TIntIntHashMap();
        _foreignWordsCounts = new TIntIntHashMap();
    }

    private BilingualCorpus() {
        counter++;
        System.out.println();
        System.out.println("BilingualCorpus instance nr " + counter);
        System.out.println();
    }

    public BilingualCorpus reverse() {
        BilingualCorpus res = new BilingualCorpus();
        res._name = _name;
        res._vocabForeign = _vocabSource;
        res._vocabSource = _vocabForeign;
        res._vocabNamesForeign = _vocabNamesSource;
        res._vocabNamesSource = _vocabNamesForeign;
        res._maxTrainingSentences = _maxTrainingSentences;
        res._trainSourceSentences = _trainForeignSentences;
        res._trainForeignSentences = _trainSourceSentences;
        res._testSourceSentences = _testForeignSentences;
        res._testForeignSentences = _testSourceSentences;
        res._devSourceSentences = _devForeignSentences;
        res._devForeignSentences = _devSourceSentences;
        res._maxTrainingSentences = _maxTrainingSentences;
        res._nrTrainingSentences = _nrTrainingSentences;
        res._maxSentenceSize = _maxSentenceSize;
        res._discardedSentences = _discardedSentences;
        if (_gold != null) {
            res._gold = _gold.reverse();
        }
        if (_devGold != null) {
            res._devGold = _devGold.reverse();
        }
        res._maxForeignLen = _maxSourceLen;
        res._maxSourceLen = _maxForeignLen;
        res._sourceFertilities = _foreignFertilities;
        res._foreignFertilities = _sourceFertilities;
        res._sourceSufix = _foreignSufix;
        res._foreignSufix = _sourceSufix;
        res._foreignWordsCounts = _sourceWordsCounts;
        res._sourceWordsCounts = _foreignWordsCounts;
        res._foreignSize = _sourceSize;
        res._sourceSize = _foreignSize;
        res.ref = new Reference(res);
        return res;
    }

    public String getName() {
        return _name;
    }

    public void printCorpusDescription() {
        System.out.println(_name);
        System.out.println(_maxSentenceSize);
        System.out.println(_maxTrainingSentences);
        System.out.println(_nrTrainingSentences);
    }

    public void saveDescription(String directory) {
        try {
            PrintStream f = new PrintStream(directory + "corpus-description");
            f.println(_name);
            f.println(_maxSentenceSize);
            f.println(_maxTrainingSentences);
            f.println(_nrTrainingSentences);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("ERROR SAVING CORPUS DESCRIPTION");
            System.exit(1);
        }
    }

    public boolean checkDescription(String directory) {
        try {
            BufferedReader in = new BufferedReader(new FileReader(directory
                    + "corpus-description"));

            String name = in.readLine();
            int maxSentences = Integer.parseInt(in.readLine());
            int maxTrainingSentences = Integer.parseInt(in.readLine());
            if (!name.equalsIgnoreCase(_name)) {
                System.out.println("Corpus name is not the same, got:" + name
                        + " have " + _name);
                return false;
            }
            if ((maxSentences != _maxSentenceSize)) {
                /*Hoang cuong - Slight modification */
                _maxSentenceSize = maxSentences;
                System.out.println("Corpus max sentence size is not the same got:"
                        + maxSentences + " have " + _maxSentenceSize);
                //return false;
            }
            if (maxTrainingSentences != _maxTrainingSentences) {
                System.out.println("Corpus nr Training sentences is not the same got:" + maxTrainingSentences + " have " + _maxTrainingSentences);
                return false;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("ERROR LOADING CORPUS DESCRIPTION");
            System.exit(1);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("ERROR LOADING CORPUS DESCRIPTION");
            System.exit(1);
        }
        return true;
    }

    public static BilingualCorpus getCorpusFromFileDescription(String file,
            int maxTrainingSentences) throws IOException {
        return getCorpusFromFileDescription(file, maxTrainingSentences,
                Integer.MAX_VALUE);
    }

    public static BilingualCorpus getCorpusFromFileDescription(String file,
            int maxTrainingSentences, int maxSentenceSize) throws IOException {
        BilingualCorpus corpus = new BilingualCorpus();
        Properties properties = new Properties();
        try {

            properties.load(new FileInputStream(file));
        } catch (IOException e) {
            throw new AssertionError("Wrong properties file " + file);
        }
        String name = properties.getProperty("name");
        String training = properties.getProperty("training_file");
        String source = properties.getProperty("source_suffix");
        String target = properties.getProperty("target_suffix");
        corpus._name = name;
        corpus._vocabForeign = new TObjectIntHashMap<String>();
        corpus._vocabSource = new TObjectIntHashMap<String>();
        corpus._vocabNamesForeign = new ArrayList<String>();
        corpus._vocabNamesSource = new ArrayList<String>();
        corpus._trainSourceSentences = new ArrayList<int[]>();
        corpus._trainForeignSentences = new ArrayList<int[]>();
        corpus._testSourceSentences = new ArrayList<int[]>();
        corpus._testForeignSentences = new ArrayList<int[]>();
        corpus._devSourceSentences = new ArrayList<int[]>();
        corpus._devForeignSentences = new ArrayList<int[]>();
        corpus._sourceWordsCounts = new TIntIntHashMap();
        corpus._foreignWordsCounts = new TIntIntHashMap();

        corpus._maxTrainingSentences = maxTrainingSentences;
        corpus._sourceSufix = source;
        corpus._foreignSufix = target;

        /*String dev = properties.getProperty("wa_dev_file");
        if (dev != null) {
            corpus.addTrainFile(dev + "." + source, dev + "." + target,
                    Integer.MAX_VALUE);
            System.out.println("Adding Dev File");
            String devGold = properties.getProperty("wa_dev_gold_file");
            if (devGold != null) {
                corpus.addDevFile(dev + "." + source, dev + "." + target);
                corpus.addDevGoldAligments(devGold);
            }
        }*/

        String test = properties.getProperty("wa_test_file");
        if (test != null) {
            System.out.println("Adding Test File ");

            corpus.addTrainFile(test + "." + source, test + "." + target,
                    Integer.MAX_VALUE);
            String testGold = properties.getProperty("wa_test_gold_file");
            if (testGold != null) {
                corpus.addTestFile(test + "." + source, test + "." + target);
                corpus.addGoldAligments(testGold);
            }
        }
        corpus.addTrainFile(training + "." + source, training + "." + target,
                maxSentenceSize);
        corpus.initialize();
        return corpus;
    }

    public int getMaxSourceLen() {
        return _maxSourceLen;
    }

    public int getMaxForeignLen() {
        return _maxForeignLen;

    }

    public String getSourceString(int i) {
        return _vocabNamesSource.get(i);
    }

    public String getForeignString(int i) {
        return _vocabNamesForeign.get(i);
    }

    public AlignmentsSet getGold() {
        return _gold;
    }

    public int getNumSentences(byte sentenceSource) {
        switch (sentenceSource) {
            case TEST_CORPUS:
                return _testSourceSentences.size();
            case DEV_CORPUS:
                return _devSourceSentences.size();
            case TRAIN_CORPUS:
                return _nrTrainingSentences;
            default:
                throw new IllegalArgumentException("Unknown sentence type:"
                        + sentenceSource);
        }
    }

    public int getNumberOfTrainingSentences() {
        return _nrTrainingSentences;
    }

    public int[] getSentencesByLen(byte sentenceSource, int min, int max) {
        ArrayList<Integer> sen = new ArrayList<Integer>();
        int[] sent;
        switch (sentenceSource) {
            case TEST_CORPUS:
                for (int i = 0; i < _testSourceSentences.size(); i++) {
                    if (_testForeignSentences.get(i).length <= max
                            && _testForeignSentences.get(i).length > min) {
                        sen.add(i);
                    }
                }
                break;
            case DEV_CORPUS:
                for (int i = 0; i < _devSourceSentences.size(); i++) {
                    if (_devForeignSentences.get(i).length <= max
                            && _devForeignSentences.get(i).length > min) {
                        sen.add(i);
                    }
                }

                break;
            case TRAIN_CORPUS:
                for (int i = 0; i < _trainSourceSentences.size(); i++) {
                    if (_trainForeignSentences.get(i).length <= max
                            && _trainForeignSentences.get(i).length > min) {
                        sen.add(i);
                    }
                }
                break;
            default:
                throw new IllegalArgumentException("Unknown sentence type:"
                        + sentenceSource);
        }
        sent = new int[sen.size()];
        for (int i = 0; i < sen.size(); i++) {
            sent[i] = sen.get(i);
        }
        return sent;
    }

    public AlignmentsSet getAlignments(int[] sentences, byte sentenceSource) {
        AlignmentsSet set = new AlignmentsSet();
        switch (sentenceSource) {
            case TEST_CORPUS:
                for (int i = 0; i < sentences.length; i++) {
                    set.addAlignment(_gold.get(sentences[i]));
                }
                return set;
            case DEV_CORPUS:
                for (int i = 0; i < sentences.length; i++) {
                    set.addAlignment(_devGold.get(sentences[i]));
                }
                return set;
        }
        return null;
    }

    public AlignmentsSet getAlignments(byte sentenceSource) {
        switch (sentenceSource) {
            case TEST_CORPUS:
                return _gold;
            case DEV_CORPUS:
                return _devGold;
        }
        return null;
    }

    public int getSourceSize() {
        return _sourceSize;
    }

    public int getTotalSourceWords() {
        int total = 0;
        for (int i = 0; i < _sourceWordsCounts.size(); i++) {
            total += _sourceWordsCounts.get(i);
        }
        return total;
    }

    public int getTotalForeignWords() {
        int total = 0;
        for (int i = 0; i < _foreignWordsCounts.size(); i++) {
            total += _foreignWordsCounts.get(i);
        }
        return total;
    }

    public int[] getFertileSource() {
        byte sentenceSource = DEV_CORPUS;
        double[] fertility = new double[getSourceSize()];
        int[] counts = new int[getSourceSize()];
        int numSents = getNumSentences(sentenceSource);
        ArrayList<Alignment> alignments = getAlignments(sentenceSource).getAlignments();
        for (int i = 0; i < numSents; i++) {
            int[] s = getSourceSentence(i, sentenceSource);
            int[] f = getForeignSentence(i, sentenceSource);
            Alignment a = alignments.get(i);
            for (int si = 0; si < s.length; si++) {
                int yesCounts = 0;
                for (int fi = 0; fi < f.length; fi++) {
                    if (a.isSure(si, fi)) {
                        yesCounts++;
                    }
                }
                if (yesCounts != 0) {
                    counts[s[si]] += 1;
                    fertility[s[si]] += yesCounts;
                }
            }
        }

        ArrayList<Integer> tmp = new ArrayList<Integer>();
        for (int i = 0; i < fertility.length; i++) {
            if (counts[i] < 2) {
                continue;
            }
            if (fertility[i] / counts[i] < 1.5) {
                continue;
            }
            System.out.println(counts[i] + "  " + fertility[i] / counts[i]
                    + "      " + getSourceWordById(i));
            tmp.add(i);
        }
        int[] fertileSource = new int[tmp.size()];
        for (int i = 0; i < tmp.size(); i++) {
            fertileSource[i] = tmp.get(i);
        }
        return fertileSource;
    }

    public String getSourceSufix() {
        return _sourceSufix;
    }

    public String getForeignSufix() {
        return _foreignSufix;
    }

    public int getForeignSize() {
        return _foreignSize;
    }

    public String getSourceWordById(int id) {
        return _vocabNamesSource.get(id);
    }

    public String getForeignWordById(int id) {
        return _vocabNamesForeign.get(id);
    }

    public int getSourceWordId(int sentenceNumber, byte sentenceSource, int i) {
        return getSourceSentence(sentenceNumber, sentenceSource)[i];
    }

    public int getForeignWordId(int sentenceNumber, byte sentenceSource, int i) {
        return getForeignSentence(sentenceNumber, sentenceSource)[i];
    }

    public String getSourceWord(int sentenceNumber, byte sentenceSource, int i) {
        return _vocabNamesSource.get(getSourceSentence(sentenceNumber,
                sentenceSource)[i]);
    }

    public String getForeignWord(int sentenceNumber, byte sentenceSource, int i) {
        return _vocabNamesForeign.get(getForeignSentence(sentenceNumber,
                sentenceSource)[i]);
    }

    public int[] getForeignSentence(int sentenceNr, byte sentenceSource) {
        switch (sentenceSource) {
            case TRAIN_CORPUS:
                return _trainForeignSentences.get(sentenceNr);
            case TEST_CORPUS:
                return _testForeignSentences.get(sentenceNr);
            case DEV_CORPUS:
                return _devForeignSentences.get(sentenceNr);
        }
        return null;
    }

    public int[] getSourceSentence(int sentenceNr, byte sentenceSource) {
        switch (sentenceSource) {
            case TRAIN_CORPUS:
                return _trainSourceSentences.get(sentenceNr);
            case TEST_CORPUS:
                return _testSourceSentences.get(sentenceNr);
            case DEV_CORPUS:
                return _devSourceSentences.get(sentenceNr);
        }
        return null;
    }

    public String getForeignSentenceString(int sentenceNr, byte sentenceSource) {
        // System.out.println("getForeignSentenceString" + sentenceNr + " " +
        // sentenceSource);
        int[] s = null;
        switch (sentenceSource) {
            case TRAIN_CORPUS:
                s = _trainForeignSentences.get(sentenceNr);
                break;
            case TEST_CORPUS:
                s = _testForeignSentences.get(sentenceNr);
                break;
            case DEV_CORPUS:
                s = _devForeignSentences.get(sentenceNr);
                break;
        }
        String sent = "";
        for (int i = 0; i < s.length; i++) {
            sent += getForeignWordById(s[i]) + " ";
        }
        return sent;
    }

    public String getSourceSentenceString(int sentenceNr, byte sentenceSource) {
        // System.out.println("getSourceSentenceString" + sentenceNr + " " +
        // sentenceSource);
        int[] s = null;
        switch (sentenceSource) {
            case TRAIN_CORPUS:
                // System.out.println("Train" + sentenceNr + " " + TRAIN_CORPUS +
                // _trainSourceSentences.size() + " " + sentenceNr);
                s = _trainSourceSentences.get(sentenceNr);
                break;
            case TEST_CORPUS:
                // System.out.println("Test" + sentenceNr + " " + TEST_CORPUS +
                // _testSourceSentences.size() + " " + sentenceNr);
                s = _testSourceSentences.get(sentenceNr);
                break;
            case DEV_CORPUS:
                // System.out.println("Dev" + sentenceNr + " " + DEV_CORPUS +
                // _devSourceSentences.size() + " " + sentenceNr);
                s = _devSourceSentences.get(sentenceNr);
                break;
        }
        String sent = "";
        for (int i = 0; i < s.length; i++) {
            sent += getSourceWordById(s[i]) + " ";
        }
        return sent;

    }

    public int getForeignSentenceLength(int sentenceNr, byte sentenceSource) {
        switch (sentenceSource) {
            case TRAIN_CORPUS:
                return _trainForeignSentences.get(sentenceNr).length;
            case TEST_CORPUS:
                return _testForeignSentences.get(sentenceNr).length;
            case DEV_CORPUS:
                return _devForeignSentences.get(sentenceNr).length;
        }
        return -1;
    }

    public int getSourceSentenceLength(int sentenceNr, byte sentenceSource) {
        switch (sentenceSource) {
            case TRAIN_CORPUS:
                return _trainSourceSentences.get(sentenceNr).length;
            case TEST_CORPUS:
                return _testSourceSentences.get(sentenceNr).length;
            case DEV_CORPUS:
                return _devSourceSentences.get(sentenceNr).length;
        }
        return -1;
    }

    public int[] convertStringToIntArray(String[] sent, int len,
            ArrayList<String> vocabNames, TObjectIntHashMap<String> vocab,
            TIntIntHashMap counts) {
        int[] reply = new int[len];
        for (int i = 0; i < len; i++) {
            if (vocab.containsKey(sent[i])) {
                int id = vocab.get(sent[i]);
                reply[i] = id;
                counts.put(id, counts.get(id) + 1);
            } else {
                vocabNames.add(sent[i]);
                vocab.put(sent[i], vocabNames.size() - 1);
                reply[i] = vocabNames.size() - 1;
                counts.put(vocabNames.size() - 1, 1);

            }
        }
        return reply;
    }

    public void addTrainFile(String sourceName, String foreignName,
            int maxSentenceSize) throws IOException {

        addTrainFile(new File(sourceName), new File(foreignName),
                maxSentenceSize);
    }

    public void addTrainFile(File sourceFile, File foreignFile,
            int maxSentenceSize) throws IOException {
        int[] result = addFile(sourceFile, foreignFile, maxSentenceSize,
                _nrTrainingSentences, _discardedSentences,
                _maxTrainingSentences, _trainSourceSentences,
                _trainForeignSentences);
        _nrTrainingSentences = result[0];
        _discardedSentences = result[1];
    }

    public void addTestFile(String sourceName, String foreignName)
            throws IOException {
        @SuppressWarnings("unused")
        int[] result = addFile(new File(sourceName), new File(foreignName),
                Integer.MAX_VALUE, _testSourceSentences.size(), 0,
                Integer.MAX_VALUE, _testSourceSentences, _testForeignSentences);
    }

    public void addDevFile(String sourceName, String foreignName)
            throws IOException {
        @SuppressWarnings("unused")
        int[] result = addFile(new File(sourceName), new File(foreignName),
                Integer.MAX_VALUE, _devSourceSentences.size(), 0,
                Integer.MAX_VALUE, _devSourceSentences, _devForeignSentences);
    }

    // Return the current number of sentences
    int[] addFile(File sourceFile, File foreignFile, int maxSentenceSize,
            int numberSentences, int discardedSentences, int maxSentences,
            ArrayList<int[]> sourceSentences, ArrayList<int[]> foreignSentences)
            throws IOException {

        maxSentenceSize += 1000; //unlimited
        System.out.println(sourceFile.getAbsolutePath());
        System.out.println(foreignFile.getAbsolutePath());
        
        
        System.out.println("hoang cuong "+_maxSentenceSize+"~"+maxSentenceSize);
        if (_maxSentenceSize == 0) {
            _maxSentenceSize = maxSentenceSize;
        } else if (maxSentenceSize <= _maxSentenceSize) {
            _maxSentenceSize = maxSentenceSize;
        }
        // System.out.println("Nr Sentences " + numberSentences + "Discarded " +
        // _discardedSentences);
        int[] result = {numberSentences, discardedSentences};
        if (result[0] >= maxSentences) {
            return result;
        }
        BufferedReader sourceReader = new BufferedReader(new InputStreamReader(
                new FileInputStream(sourceFile), "UTF8"));
        BufferedReader foreignReader = new BufferedReader(
                new InputStreamReader(new FileInputStream(foreignFile), "UTF8"));
        String sourceSentence = sourceReader.readLine();
        String foreignSentence = foreignReader.readLine();
        int i = 0;
        while (sourceSentence != null && foreignSentence != null) {
            String[] sourceTokens = sourceSentence.split(" ");
            int sourceLen = sourceTokens.length;
            String[] foreignTokens = foreignSentence.split(" ");
            int foreignLen = foreignTokens.length;
            // FIXME should be <=
            
            
            
            //Hoang Cuong - slight modification
            
            if (sourceLen > _maxSourceLen) {
                _maxSourceLen = sourceLen;
            }
            // System.out.println(foreignLen + " " + _maxForeignLen);
            if (foreignLen > _maxForeignLen) {
                _maxForeignLen = foreignLen;
            }
            sourceSentences.add(i, convertStringToIntArray(sourceTokens,
                    sourceLen, _vocabNamesSource, _vocabSource,
                    _sourceWordsCounts));
            foreignSentences.add(i, convertStringToIntArray(foreignTokens,
                    foreignLen, _vocabNamesForeign, _vocabForeign,
                    _foreignWordsCounts));
            result[0]++;
            

                
            i++;
            sourceSentence = sourceReader.readLine();
            foreignSentence = foreignReader.readLine();
        }
        System.out.println(result[0]);
        return result;
    }

    public void addGoldAligments(String fileName) throws IOException {
        _gold = AlignmentsSet.getAlignmentFromFileNAACL(fileName,
                BilingualCorpus.TEST_CORPUS, this, 0);
        // for(Alignment2 al: _gold.getAlignments())
        // AlignerOutput2.output(al, this, System.out);
    }

    public void addDevGoldAligments(String fileName) throws IOException {
        _devGold = AlignmentsSet.getAlignmentFromFileNAACL(fileName,
                BilingualCorpus.DEV_CORPUS, this, 0);
    }

    public void addTrainDirectory(String sourceDirectoryName,
            String foreignDirectoryName, int maxSentenceSize)
            throws IOException {
        if (_nrTrainingSentences >= _maxTrainingSentences) {
            return;
        }
        File sourceDir = new File(sourceDirectoryName);
        File foreignDir = new File(foreignDirectoryName);
        File[] sourceFiles = sourceDir.listFiles();
        File[] foreignFiles = foreignDir.listFiles();
        Arrays.sort(sourceFiles);
        // shuffle(sourceFiles);
        if (sourceFiles.length != foreignFiles.length) {
            throw new RuntimeException(
                    "source and foreign have different number of files");
        }
        for (File sf : sourceFiles) {
            String fpath = foreignDirectoryName + "/" + sf.getName();
            // System.out.println(sf.getName());
            if (_nrTrainingSentences == _maxTrainingSentences) {
                return;
            }
            addTrainFile(sf, new File(fpath), maxSentenceSize);
        }
    }

    // TODO This method has to be called
    public void initialize() {
        System.out.println("Initializing Corpus");

        _sourceSize = _vocabSource.size();
        _foreignSize = _vocabForeign.size();
        /*
         * if(_devGold != null){ //Calculate empirical fertilities
         * _foreignFertilities =
         * AlignmentEvaluator.calculateFertilities(_devGold.getAlignments(),
         * this, DEV_CORPUS); BilingualCorpus rev = this.reverse();
         * _sourceFertilities =
         * AlignmentEvaluator.calculateFertilities(rev._devGold.getAlignments(),
         * rev, DEV_CORPUS); }
         */

        ref = new Reference(this);
        System.out.println("Finished Initializing Corpus: Used "
                + _nrTrainingSentences + " sentences, discarded "
                + _discardedSentences);
    }

    public void printVocab(ArrayList<String> vocab) {
        for (int i = 0; i < vocab.size(); i++) {
            System.out.println(i + 1 + " - " + vocab.get(i));
        }
    }

    public boolean sourceSentenceContainsRareWord(int sentenceNr,
            byte sentenceSource) {
        int[] sentence = getSourceSentence(sentenceNr, sentenceSource);
        for (int i = 0; i < sentence.length; i++) {
            if (sourceRareWord(sentence[i])) {
                return true;
            }
        }
        return false;
    }

    public boolean foreignRareWord(int foreingId) {
        return _foreignWordsCounts.get(foreingId) < 5;
    }

    public boolean foreignRareWord(int foreingId, int nr) {
        return _foreignWordsCounts.get(foreingId) < nr;
    }

    public int getSourceWordCounts(int sourceId) {
        return _sourceWordsCounts.get(sourceId);
    }

    public boolean sourceRareWord(int sourceId) {
        return _sourceWordsCounts.get(sourceId) < 5;
    }

    public boolean sourceRareWord(int sourceId, int nr) {
        return _sourceWordsCounts.get(sourceId) < nr;
    }

    public boolean foreignHighFertilityWord(int foreignId) {
        if (_foreignFertilities[foreignId] >= 2) {
            return true;
        }
        return false;
    }

    public double numberOfForeignRareWords() {
        int rare = 0;
        int all = 0;
        for (int i = 0; i < _foreignWordsCounts.size(); i++) {
            if (_foreignWordsCounts.get(i) < 5) {
                rare += _foreignWordsCounts.get(i);
            }
            all += _foreignWordsCounts.get(i);
        }
        return rare * 1.0 / all;
    }

    public double numberOfSourceRareWords() {
        int rare = 0;
        int all = 0;
        for (int i = 0; i < _sourceWordsCounts.size(); i++) {
            if (_sourceWordsCounts.get(i) < 5) {
                rare += _sourceWordsCounts.get(i);
            }
            all += _sourceWordsCounts.get(i);
        }
        return rare * 1.0 / all;
    }

    public static void main(String[] args) throws IOException {
        String corpusFile = args[0];
        int size = Integer.parseInt(args[1]);
        // int maxSentenceSize = Integer.parseInt(args[2]);

        // System.out.println("Corpus "+corpusName);
        // System.out.println("Size "+size);
        // System.out.println("Max Sentence size "+maxSentenceSize);

        /*
         * Corpora.Cpr2 c = new Corpora.Cpr2(corpusName, size,maxSentenceSize);
         * BilingualCorpus bi = c.bi; double sourceRare
         * =bi.numberOfSourceRareWords(); double foreignRare
         * =bi.numberOfForeignRareWords();
         * 
         * 
         * System.out.println("Foreign rare" + sourceRare );
         * System.out.println("Source rare" + foreignRare );
         */
        System.gc();
        System.gc();
        System.gc();
        double initM = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory())
                / (1024 * 1024);
        long init = System.currentTimeMillis();
        BilingualCorpus corpus = BilingualCorpus.getCorpusFromFileDescription(
                corpusFile, size);
        long end = System.currentTimeMillis();
        System.gc();
        System.gc();
        System.gc();
        double endM = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory())
                / (1024 * 1024);

        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println("Init corpus Spent Memory " + (endM - initM)
                + " time " + (end - init));
        System.out.println();
        System.out.println();
        System.out.println();

        System.gc();
        System.gc();
        System.gc();
        initM = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory())
                / (1024 * 1024);
        corpus.trim();
        System.gc();
        System.gc();
        System.gc();
        endM = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory())
                / (1024 * 1024);
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println("Corpus after Trim memory" + endM);
        System.out.println();
        System.out.println();
        System.out.println();

        System.out.println("Ended Corpus");

    }
}
